/*!
 * Bootstrap v5.3.0 (https://getbootstrap.com/)
 * Copyright 2011-2023 The Bootstrap Authors (https://github.com/twbs/bootstrap/graphs/contributors)
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/main/LICENSE)
 */
!(function (e, t) {
  "object" == typeof exports && "undefined" != typeof module
    ? (module.exports = t())
    : "function" == typeof define && define.amd
    ? define(t)
    : ((e =
        "undefined" != typeof globalThis ? globalThis : e || self).bootstrap =
        t());
})(this, function () {
  "use strict";
  const e = new Map(),
    t = {
      set(t, n, i) {
        e.has(t) || e.set(t, new Map());
        const r = e.get(t);
        r.has(n) || 0 === r.size
          ? r.set(n, i)
          : console.error(
              `Bootstrap doesn't allow more than one instance per element. Bound instance: ${
                Array.from(r.keys())[0]
              }.`
            );
      },
      get: (t, n) => (e.has(t) && e.get(t).get(n)) || null,
      remove(t, n) {
        if (!e.has(t)) return;
        const i = e.get(t);
        i.delete(n), 0 === i.size && e.delete(t);
      },
    },
    n = "transitionend",
    i = (e) => (
      e &&
        window.CSS &&
        window.CSS.escape &&
        (e = e.replace(/#([^\s"#']+)/g, (e, t) => "#" + CSS.escape(t))),
      e
    ),
    r = (e) => {
      e.dispatchEvent(new Event(n));
    },
    s = (e) =>
      !(!e || "object" != typeof e) &&
      (void 0 !== e.jquery && (e = e[0]), void 0 !== e.nodeType),
    o = (e) =>
      s(e)
        ? e.jquery
          ? e[0]
          : e
        : "string" == typeof e && e.length > 0
        ? document.querySelector(i(e))
        : null,
    a = (e) => {
      if (!s(e) || 0 === e.getClientRects().length) return !1;
      const t =
          "visible" === getComputedStyle(e).getPropertyValue("visibility"),
        n = e.closest("details:not([open])");
      if (!n) return t;
      if (n !== e) {
        const t = e.closest("summary");
        if (t && t.parentNode !== n) return !1;
        if (null === t) return !1;
      }
      return t;
    },
    l = (e) =>
      !e ||
      e.nodeType !== Node.ELEMENT_NODE ||
      !!e.classList.contains("disabled") ||
      (void 0 !== e.disabled
        ? e.disabled
        : e.hasAttribute("disabled") && "false" !== e.getAttribute("disabled")),
    c = (e) => {
      if (!document.documentElement.attachShadow) return null;
      if ("function" == typeof e.getRootNode) {
        const t = e.getRootNode();
        return t instanceof ShadowRoot ? t : null;
      }
      return e instanceof ShadowRoot
        ? e
        : e.parentNode
        ? c(e.parentNode)
        : null;
    },
    u = () => {},
    d = (e) => {
      e.offsetHeight;
    },
    h = () =>
      window.jQuery && !document.body.hasAttribute("data-bs-no-jquery")
        ? window.jQuery
        : null,
    f = [],
    p = () => "rtl" === document.documentElement.dir,
    g = (e) => {
      var t;
      (t = () => {
        const t = h();
        if (t) {
          const n = e.NAME,
            i = t.fn[n];
          (t.fn[n] = e.jQueryInterface),
            (t.fn[n].Constructor = e),
            (t.fn[n].noConflict = () => ((t.fn[n] = i), e.jQueryInterface));
        }
      }),
        "loading" === document.readyState
          ? (f.length ||
              document.addEventListener("DOMContentLoaded", () => {
                for (const e of f) e();
              }),
            f.push(t))
          : t();
    },
    m = (e, t = [], n = e) => ("function" == typeof e ? e(...t) : n),
    b = (e, t, i = !0) => {
      if (!i) return void m(e);
      const s =
        ((e) => {
          if (!e) return 0;
          let { transitionDuration: t, transitionDelay: n } =
            window.getComputedStyle(e);
          const i = Number.parseFloat(t),
            r = Number.parseFloat(n);
          return i || r
            ? ((t = t.split(",")[0]),
              (n = n.split(",")[0]),
              1e3 * (Number.parseFloat(t) + Number.parseFloat(n)))
            : 0;
        })(t) + 5;
      let o = !1;
      const a = ({ target: i }) => {
        i === t && ((o = !0), t.removeEventListener(n, a), m(e));
      };
      t.addEventListener(n, a),
        setTimeout(() => {
          o || r(t);
        }, s);
    },
    _ = (e, t, n, i) => {
      const r = e.length;
      let s = e.indexOf(t);
      return -1 === s
        ? !n && i
          ? e[r - 1]
          : e[0]
        : ((s += n ? 1 : -1),
          i && (s = (s + r) % r),
          e[Math.max(0, Math.min(s, r - 1))]);
    },
    y = /[^.]*(?=\..*)\.|.*/,
    v = /\..*/,
    w = /::\d+$/,
    A = {};
  let E = 1;
  const x = { mouseenter: "mouseover", mouseleave: "mouseout" },
    k = new Set([
      "click",
      "dblclick",
      "mouseup",
      "mousedown",
      "contextmenu",
      "mousewheel",
      "DOMMouseScroll",
      "mouseover",
      "mouseout",
      "mousemove",
      "selectstart",
      "selectend",
      "keydown",
      "keypress",
      "keyup",
      "orientationchange",
      "touchstart",
      "touchmove",
      "touchend",
      "touchcancel",
      "pointerdown",
      "pointermove",
      "pointerup",
      "pointerleave",
      "pointercancel",
      "gesturestart",
      "gesturechange",
      "gestureend",
      "focus",
      "blur",
      "change",
      "reset",
      "select",
      "submit",
      "focusin",
      "focusout",
      "load",
      "unload",
      "beforeunload",
      "resize",
      "move",
      "DOMContentLoaded",
      "readystatechange",
      "error",
      "abort",
      "scroll",
    ]);
  function S(e, t) {
    return (t && `${t}::${E++}`) || e.uidEvent || E++;
  }
  function T(e) {
    const t = S(e);
    return (e.uidEvent = t), (A[t] = A[t] || {}), A[t];
  }
  function P(e, t, n = null) {
    return Object.values(e).find(
      (e) => e.callable === t && e.delegationSelector === n
    );
  }
  function C(e, t, n) {
    const i = "string" == typeof t,
      r = i ? n : t || n;
    let s = D(e);
    return k.has(s) || (s = e), [i, r, s];
  }
  function O(e, t, n, i, r) {
    if ("string" != typeof t || !e) return;
    let [s, o, a] = C(t, n, i);
    if (t in x) {
      o = ((e) =>
        function (t) {
          if (
            !t.relatedTarget ||
            (t.relatedTarget !== t.delegateTarget &&
              !t.delegateTarget.contains(t.relatedTarget))
          )
            return e.call(this, t);
        })(o);
    }
    const l = T(e),
      c = l[a] || (l[a] = {}),
      u = P(c, o, s ? n : null);
    if (u) return void (u.oneOff = u.oneOff && r);
    const d = S(o, t.replace(y, "")),
      h = s
        ? (function (e, t, n) {
            return function i(r) {
              const s = e.querySelectorAll(t);
              for (let { target: o } = r; o && o !== this; o = o.parentNode)
                for (const a of s)
                  if (a === o)
                    return (
                      I(r, { delegateTarget: o }),
                      i.oneOff && j.off(e, r.type, t, n),
                      n.apply(o, [r])
                    );
            };
          })(e, n, o)
        : (function (e, t) {
            return function n(i) {
              return (
                I(i, { delegateTarget: e }),
                n.oneOff && j.off(e, i.type, t),
                t.apply(e, [i])
              );
            };
          })(e, o);
    (h.delegationSelector = s ? n : null),
      (h.callable = o),
      (h.oneOff = r),
      (h.uidEvent = d),
      (c[d] = h),
      e.addEventListener(a, h, s);
  }
  function L(e, t, n, i, r) {
    const s = P(t[n], i, r);
    s && (e.removeEventListener(n, s, Boolean(r)), delete t[n][s.uidEvent]);
  }
  function F(e, t, n, i) {
    const r = t[n] || {};
    for (const [s, o] of Object.entries(r))
      s.includes(i) && L(e, t, n, o.callable, o.delegationSelector);
  }
  function D(e) {
    return (e = e.replace(v, "")), x[e] || e;
  }
  const j = {
    on(e, t, n, i) {
      O(e, t, n, i, !1);
    },
    one(e, t, n, i) {
      O(e, t, n, i, !0);
    },
    off(e, t, n, i) {
      if ("string" != typeof t || !e) return;
      const [r, s, o] = C(t, n, i),
        a = o !== t,
        l = T(e),
        c = l[o] || {},
        u = t.startsWith(".");
      if (void 0 === s) {
        if (u) for (const n of Object.keys(l)) F(e, l, n, t.slice(1));
        for (const [n, i] of Object.entries(c)) {
          const r = n.replace(w, "");
          (a && !t.includes(r)) || L(e, l, o, i.callable, i.delegationSelector);
        }
      } else {
        if (!Object.keys(c).length) return;
        L(e, l, o, s, r ? n : null);
      }
    },
    trigger(e, t, n) {
      if ("string" != typeof t || !e) return null;
      const i = h();
      let r = null,
        s = !0,
        o = !0,
        a = !1;
      t !== D(t) &&
        i &&
        ((r = i.Event(t, n)),
        i(e).trigger(r),
        (s = !r.isPropagationStopped()),
        (o = !r.isImmediatePropagationStopped()),
        (a = r.isDefaultPrevented()));
      const l = I(new Event(t, { bubbles: s, cancelable: !0 }), n);
      return (
        a && l.preventDefault(),
        o && e.dispatchEvent(l),
        l.defaultPrevented && r && r.preventDefault(),
        l
      );
    },
  };
  function I(e, t = {}) {
    for (const [n, i] of Object.entries(t))
      try {
        e[n] = i;
      } catch (t) {
        Object.defineProperty(e, n, { configurable: !0, get: () => i });
      }
    return e;
  }
  function M(e) {
    if ("true" === e) return !0;
    if ("false" === e) return !1;
    if (e === Number(e).toString()) return Number(e);
    if ("" === e || "null" === e) return null;
    if ("string" != typeof e) return e;
    try {
      return JSON.parse(decodeURIComponent(e));
    } catch (t) {
      return e;
    }
  }
  function N(e) {
    return e.replace(/[A-Z]/g, (e) => "-" + e.toLowerCase());
  }
  const $ = {
    setDataAttribute(e, t, n) {
      e.setAttribute("data-bs-" + N(t), n);
    },
    removeDataAttribute(e, t) {
      e.removeAttribute("data-bs-" + N(t));
    },
    getDataAttributes(e) {
      if (!e) return {};
      const t = {},
        n = Object.keys(e.dataset).filter(
          (e) => e.startsWith("bs") && !e.startsWith("bsConfig")
        );
      for (const i of n) {
        let n = i.replace(/^bs/, "");
        (n = n.charAt(0).toLowerCase() + n.slice(1, n.length)),
          (t[n] = M(e.dataset[i]));
      }
      return t;
    },
    getDataAttribute: (e, t) => M(e.getAttribute("data-bs-" + N(t))),
  };
  class H {
    static get Default() {
      return {};
    }
    static get DefaultType() {
      return {};
    }
    static get NAME() {
      throw new Error(
        'You have to implement the static method "NAME", for each component!'
      );
    }
    _getConfig(e) {
      return (
        (e = this._mergeConfigObj(e)),
        (e = this._configAfterMerge(e)),
        this._typeCheckConfig(e),
        e
      );
    }
    _configAfterMerge(e) {
      return e;
    }
    _mergeConfigObj(e, t) {
      const n = s(t) ? $.getDataAttribute(t, "config") : {};
      return {
        ...this.constructor.Default,
        ...("object" == typeof n ? n : {}),
        ...(s(t) ? $.getDataAttributes(t) : {}),
        ...("object" == typeof e ? e : {}),
      };
    }
    _typeCheckConfig(e, t = this.constructor.DefaultType) {
      for (const [i, r] of Object.entries(t)) {
        const t = e[i],
          o = s(t)
            ? "element"
            : null == (n = t)
            ? "" + n
            : Object.prototype.toString
                .call(n)
                .match(/\s([a-z]+)/i)[1]
                .toLowerCase();
        if (!new RegExp(r).test(o))
          throw new TypeError(
            `${this.constructor.NAME.toUpperCase()}: Option "${i}" provided type "${o}" but expected type "${r}".`
          );
      }
      var n;
    }
  }
  class B extends H {
    constructor(e, n) {
      super(),
        (e = o(e)) &&
          ((this._element = e),
          (this._config = this._getConfig(n)),
          t.set(this._element, this.constructor.DATA_KEY, this));
    }
    dispose() {
      t.remove(this._element, this.constructor.DATA_KEY),
        j.off(this._element, this.constructor.EVENT_KEY);
      for (const e of Object.getOwnPropertyNames(this)) this[e] = null;
    }
    _queueCallback(e, t, n = !0) {
      b(e, t, n);
    }
    _getConfig(e) {
      return (
        (e = this._mergeConfigObj(e, this._element)),
        (e = this._configAfterMerge(e)),
        this._typeCheckConfig(e),
        e
      );
    }
    static getInstance(e) {
      return t.get(o(e), this.DATA_KEY);
    }
    static getOrCreateInstance(e, t = {}) {
      return (
        this.getInstance(e) || new this(e, "object" == typeof t ? t : null)
      );
    }
    static get VERSION() {
      return "5.3.0";
    }
    static get DATA_KEY() {
      return "bs." + this.NAME;
    }
    static get EVENT_KEY() {
      return "." + this.DATA_KEY;
    }
    static eventName(e) {
      return `${e}${this.EVENT_KEY}`;
    }
  }
  const V = (e) => {
      let t = e.getAttribute("data-bs-target");
      if (!t || "#" === t) {
        let n = e.getAttribute("href");
        if (!n || (!n.includes("#") && !n.startsWith("."))) return null;
        n.includes("#") && !n.startsWith("#") && (n = "#" + n.split("#")[1]),
          (t = n && "#" !== n ? n.trim() : null);
      }
      return i(t);
    },
    z = {
      find: (e, t = document.documentElement) =>
        [].concat(...Element.prototype.querySelectorAll.call(t, e)),
      findOne: (e, t = document.documentElement) =>
        Element.prototype.querySelector.call(t, e),
      children: (e, t) => [].concat(...e.children).filter((e) => e.matches(t)),
      parents(e, t) {
        const n = [];
        let i = e.parentNode.closest(t);
        for (; i; ) n.push(i), (i = i.parentNode.closest(t));
        return n;
      },
      prev(e, t) {
        let n = e.previousElementSibling;
        for (; n; ) {
          if (n.matches(t)) return [n];
          n = n.previousElementSibling;
        }
        return [];
      },
      next(e, t) {
        let n = e.nextElementSibling;
        for (; n; ) {
          if (n.matches(t)) return [n];
          n = n.nextElementSibling;
        }
        return [];
      },
      focusableChildren(e) {
        const t = [
          "a",
          "button",
          "input",
          "textarea",
          "select",
          "details",
          "[tabindex]",
          '[contenteditable="true"]',
        ]
          .map((e) => e + ':not([tabindex^="-"])')
          .join(",");
        return this.find(t, e).filter((e) => !l(e) && a(e));
      },
      getSelectorFromElement(e) {
        const t = V(e);
        return t && z.findOne(t) ? t : null;
      },
      getElementFromSelector(e) {
        const t = V(e);
        return t ? z.findOne(t) : null;
      },
      getMultipleElementsFromSelector(e) {
        const t = V(e);
        return t ? z.find(t) : [];
      },
    },
    R = (e, t = "hide") => {
      const n = "click.dismiss" + e.EVENT_KEY,
        i = e.NAME;
      j.on(document, n, `[data-bs-dismiss="${i}"]`, function (n) {
        if (
          (["A", "AREA"].includes(this.tagName) && n.preventDefault(), l(this))
        )
          return;
        const r = z.getElementFromSelector(this) || this.closest("." + i);
        e.getOrCreateInstance(r)[t]();
      });
    };
  class W extends B {
    static get NAME() {
      return "alert";
    }
    close() {
      if (j.trigger(this._element, "close.bs.alert").defaultPrevented) return;
      this._element.classList.remove("show");
      const e = this._element.classList.contains("fade");
      this._queueCallback(() => this._destroyElement(), this._element, e);
    }
    _destroyElement() {
      this._element.remove(),
        j.trigger(this._element, "closed.bs.alert"),
        this.dispose();
    }
    static jQueryInterface(e) {
      return this.each(function () {
        const t = W.getOrCreateInstance(this);
        if ("string" == typeof e) {
          if (void 0 === t[e] || e.startsWith("_") || "constructor" === e)
            throw new TypeError(`No method named "${e}"`);
          t[e](this);
        }
      });
    }
  }
  R(W, "close"), g(W);
  const q = '[data-bs-toggle="button"]';
  class U extends B {
    static get NAME() {
      return "button";
    }
    toggle() {
      this._element.setAttribute(
        "aria-pressed",
        this._element.classList.toggle("active")
      );
    }
    static jQueryInterface(e) {
      return this.each(function () {
        const t = U.getOrCreateInstance(this);
        "toggle" === e && t[e]();
      });
    }
  }
  j.on(document, "click.bs.button.data-api", q, (e) => {
    e.preventDefault();
    const t = e.target.closest(q);
    U.getOrCreateInstance(t).toggle();
  }),
    g(U);
  const Y = { endCallback: null, leftCallback: null, rightCallback: null },
    X = {
      endCallback: "(function|null)",
      leftCallback: "(function|null)",
      rightCallback: "(function|null)",
    };
  class K extends H {
    constructor(e, t) {
      super(),
        (this._element = e),
        e &&
          K.isSupported() &&
          ((this._config = this._getConfig(t)),
          (this._deltaX = 0),
          (this._supportPointerEvents = Boolean(window.PointerEvent)),
          this._initEvents());
    }
    static get Default() {
      return Y;
    }
    static get DefaultType() {
      return X;
    }
    static get NAME() {
      return "swipe";
    }
    dispose() {
      j.off(this._element, ".bs.swipe");
    }
    _start(e) {
      this._supportPointerEvents
        ? this._eventIsPointerPenTouch(e) && (this._deltaX = e.clientX)
        : (this._deltaX = e.touches[0].clientX);
    }
    _end(e) {
      this._eventIsPointerPenTouch(e) &&
        (this._deltaX = e.clientX - this._deltaX),
        this._handleSwipe(),
        m(this._config.endCallback);
    }
    _move(e) {
      this._deltaX =
        e.touches && e.touches.length > 1
          ? 0
          : e.touches[0].clientX - this._deltaX;
    }
    _handleSwipe() {
      const e = Math.abs(this._deltaX);
      if (e <= 40) return;
      const t = e / this._deltaX;
      (this._deltaX = 0),
        t && m(t > 0 ? this._config.rightCallback : this._config.leftCallback);
    }
    _initEvents() {
      this._supportPointerEvents
        ? (j.on(this._element, "pointerdown.bs.swipe", (e) => this._start(e)),
          j.on(this._element, "pointerup.bs.swipe", (e) => this._end(e)),
          this._element.classList.add("pointer-event"))
        : (j.on(this._element, "touchstart.bs.swipe", (e) => this._start(e)),
          j.on(this._element, "touchmove.bs.swipe", (e) => this._move(e)),
          j.on(this._element, "touchend.bs.swipe", (e) => this._end(e)));
    }
    _eventIsPointerPenTouch(e) {
      return (
        this._supportPointerEvents &&
        ("pen" === e.pointerType || "touch" === e.pointerType)
      );
    }
    static isSupported() {
      return (
        "ontouchstart" in document.documentElement ||
        navigator.maxTouchPoints > 0
      );
    }
  }
  const Q = "next",
    Z = "prev",
    J = "left",
    G = "right",
    ee = "slid.bs.carousel",
    te = "carousel",
    ne = "active",
    ie = { ArrowLeft: G, ArrowRight: J },
    re = {
      interval: 5e3,
      keyboard: !0,
      pause: "hover",
      ride: !1,
      touch: !0,
      wrap: !0,
    },
    se = {
      interval: "(number|boolean)",
      keyboard: "boolean",
      pause: "(string|boolean)",
      ride: "(boolean|string)",
      touch: "boolean",
      wrap: "boolean",
    };
  class oe extends B {
    constructor(e, t) {
      super(e, t),
        (this._interval = null),
        (this._activeElement = null),
        (this._isSliding = !1),
        (this.touchTimeout = null),
        (this._swipeHelper = null),
        (this._indicatorsElement = z.findOne(
          ".carousel-indicators",
          this._element
        )),
        this._addEventListeners(),
        this._config.ride === te && this.cycle();
    }
    static get Default() {
      return re;
    }
    static get DefaultType() {
      return se;
    }
    static get NAME() {
      return "carousel";
    }
    next() {
      this._slide(Q);
    }
    nextWhenVisible() {
      !document.hidden && a(this._element) && this.next();
    }
    prev() {
      this._slide(Z);
    }
    pause() {
      this._isSliding && r(this._element), this._clearInterval();
    }
    cycle() {
      this._clearInterval(),
        this._updateInterval(),
        (this._interval = setInterval(
          () => this.nextWhenVisible(),
          this._config.interval
        ));
    }
    _maybeEnableCycle() {
      this._config.ride &&
        (this._isSliding
          ? j.one(this._element, ee, () => this.cycle())
          : this.cycle());
    }
    to(e) {
      const t = this._getItems();
      if (e > t.length - 1 || e < 0) return;
      if (this._isSliding)
        return void j.one(this._element, ee, () => this.to(e));
      const n = this._getItemIndex(this._getActive());
      if (n === e) return;
      const i = e > n ? Q : Z;
      this._slide(i, t[e]);
    }
    dispose() {
      this._swipeHelper && this._swipeHelper.dispose(), super.dispose();
    }
    _configAfterMerge(e) {
      return (e.defaultInterval = e.interval), e;
    }
    _addEventListeners() {
      this._config.keyboard &&
        j.on(this._element, "keydown.bs.carousel", (e) => this._keydown(e)),
        "hover" === this._config.pause &&
          (j.on(this._element, "mouseenter.bs.carousel", () => this.pause()),
          j.on(this._element, "mouseleave.bs.carousel", () =>
            this._maybeEnableCycle()
          )),
        this._config.touch && K.isSupported() && this._addTouchEventListeners();
    }
    _addTouchEventListeners() {
      for (const e of z.find(".carousel-item img", this._element))
        j.on(e, "dragstart.bs.carousel", (e) => e.preventDefault());
      const e = {
        leftCallback: () => this._slide(this._directionToOrder(J)),
        rightCallback: () => this._slide(this._directionToOrder(G)),
        endCallback: () => {
          "hover" === this._config.pause &&
            (this.pause(),
            this.touchTimeout && clearTimeout(this.touchTimeout),
            (this.touchTimeout = setTimeout(
              () => this._maybeEnableCycle(),
              500 + this._config.interval
            )));
        },
      };
      this._swipeHelper = new K(this._element, e);
    }
    _keydown(e) {
      if (/input|textarea/i.test(e.target.tagName)) return;
      const t = ie[e.key];
      t && (e.preventDefault(), this._slide(this._directionToOrder(t)));
    }
    _getItemIndex(e) {
      return this._getItems().indexOf(e);
    }
    _setActiveIndicatorElement(e) {
      if (!this._indicatorsElement) return;
      const t = z.findOne(".active", this._indicatorsElement);
      t.classList.remove(ne), t.removeAttribute("aria-current");
      const n = z.findOne(`[data-bs-slide-to="${e}"]`, this._indicatorsElement);
      n && (n.classList.add(ne), n.setAttribute("aria-current", "true"));
    }
    _updateInterval() {
      const e = this._activeElement || this._getActive();
      if (!e) return;
      const t = Number.parseInt(e.getAttribute("data-bs-interval"), 10);
      this._config.interval = t || this._config.defaultInterval;
    }
    _slide(e, t = null) {
      if (this._isSliding) return;
      const n = this._getActive(),
        i = e === Q,
        r = t || _(this._getItems(), n, i, this._config.wrap);
      if (r === n) return;
      const s = this._getItemIndex(r),
        o = (t) =>
          j.trigger(this._element, t, {
            relatedTarget: r,
            direction: this._orderToDirection(e),
            from: this._getItemIndex(n),
            to: s,
          });
      if (o("slide.bs.carousel").defaultPrevented) return;
      if (!n || !r) return;
      const a = Boolean(this._interval);
      this.pause(),
        (this._isSliding = !0),
        this._setActiveIndicatorElement(s),
        (this._activeElement = r);
      const l = i ? "carousel-item-start" : "carousel-item-end",
        c = i ? "carousel-item-next" : "carousel-item-prev";
      r.classList.add(c),
        d(r),
        n.classList.add(l),
        r.classList.add(l),
        this._queueCallback(
          () => {
            r.classList.remove(l, c),
              r.classList.add(ne),
              n.classList.remove(ne, c, l),
              (this._isSliding = !1),
              o(ee);
          },
          n,
          this._isAnimated()
        ),
        a && this.cycle();
    }
    _isAnimated() {
      return this._element.classList.contains("slide");
    }
    _getActive() {
      return z.findOne(".active.carousel-item", this._element);
    }
    _getItems() {
      return z.find(".carousel-item", this._element);
    }
    _clearInterval() {
      this._interval &&
        (clearInterval(this._interval), (this._interval = null));
    }
    _directionToOrder(e) {
      return p() ? (e === J ? Z : Q) : e === J ? Q : Z;
    }
    _orderToDirection(e) {
      return p() ? (e === Z ? J : G) : e === Z ? G : J;
    }
    static jQueryInterface(e) {
      return this.each(function () {
        const t = oe.getOrCreateInstance(this, e);
        if ("number" != typeof e) {
          if ("string" == typeof e) {
            if (void 0 === t[e] || e.startsWith("_") || "constructor" === e)
              throw new TypeError(`No method named "${e}"`);
            t[e]();
          }
        } else t.to(e);
      });
    }
  }
  j.on(
    document,
    "click.bs.carousel.data-api",
    "[data-bs-slide], [data-bs-slide-to]",
    function (e) {
      const t = z.getElementFromSelector(this);
      if (!t || !t.classList.contains(te)) return;
      e.preventDefault();
      const n = oe.getOrCreateInstance(t),
        i = this.getAttribute("data-bs-slide-to");
      return i
        ? (n.to(i), void n._maybeEnableCycle())
        : "next" === $.getDataAttribute(this, "slide")
        ? (n.next(), void n._maybeEnableCycle())
        : (n.prev(), void n._maybeEnableCycle());
    }
  ),
    j.on(window, "load.bs.carousel.data-api", () => {
      const e = z.find('[data-bs-ride="carousel"]');
      for (const t of e) oe.getOrCreateInstance(t);
    }),
    g(oe);
  const ae = "show",
    le = "collapse",
    ce = "collapsing",
    ue = '[data-bs-toggle="collapse"]',
    de = { parent: null, toggle: !0 },
    he = { parent: "(null|element)", toggle: "boolean" };
  class fe extends B {
    constructor(e, t) {
      super(e, t), (this._isTransitioning = !1), (this._triggerArray = []);
      const n = z.find(ue);
      for (const e of n) {
        const t = z.getSelectorFromElement(e),
          n = z.find(t).filter((e) => e === this._element);
        null !== t && n.length && this._triggerArray.push(e);
      }
      this._initializeChildren(),
        this._config.parent ||
          this._addAriaAndCollapsedClass(this._triggerArray, this._isShown()),
        this._config.toggle && this.toggle();
    }
    static get Default() {
      return de;
    }
    static get DefaultType() {
      return he;
    }
    static get NAME() {
      return "collapse";
    }
    toggle() {
      this._isShown() ? this.hide() : this.show();
    }
    show() {
      if (this._isTransitioning || this._isShown()) return;
      let e = [];
      if (
        (this._config.parent &&
          (e = this._getFirstLevelChildren(
            ".collapse.show, .collapse.collapsing"
          )
            .filter((e) => e !== this._element)
            .map((e) => fe.getOrCreateInstance(e, { toggle: !1 }))),
        e.length && e[0]._isTransitioning)
      )
        return;
      if (j.trigger(this._element, "show.bs.collapse").defaultPrevented) return;
      for (const t of e) t.hide();
      const t = this._getDimension();
      this._element.classList.remove(le),
        this._element.classList.add(ce),
        (this._element.style[t] = 0),
        this._addAriaAndCollapsedClass(this._triggerArray, !0),
        (this._isTransitioning = !0);
      const n = "scroll" + (t[0].toUpperCase() + t.slice(1));
      this._queueCallback(
        () => {
          (this._isTransitioning = !1),
            this._element.classList.remove(ce),
            this._element.classList.add(le, ae),
            (this._element.style[t] = ""),
            j.trigger(this._element, "shown.bs.collapse");
        },
        this._element,
        !0
      ),
        (this._element.style[t] = this._element[n] + "px");
    }
    hide() {
      if (this._isTransitioning || !this._isShown()) return;
      if (j.trigger(this._element, "hide.bs.collapse").defaultPrevented) return;
      const e = this._getDimension();
      (this._element.style[e] =
        this._element.getBoundingClientRect()[e] + "px"),
        d(this._element),
        this._element.classList.add(ce),
        this._element.classList.remove(le, ae);
      for (const e of this._triggerArray) {
        const t = z.getElementFromSelector(e);
        t && !this._isShown(t) && this._addAriaAndCollapsedClass([e], !1);
      }
      (this._isTransitioning = !0),
        (this._element.style[e] = ""),
        this._queueCallback(
          () => {
            (this._isTransitioning = !1),
              this._element.classList.remove(ce),
              this._element.classList.add(le),
              j.trigger(this._element, "hidden.bs.collapse");
          },
          this._element,
          !0
        );
    }
    _isShown(e = this._element) {
      return e.classList.contains(ae);
    }
    _configAfterMerge(e) {
      return (e.toggle = Boolean(e.toggle)), (e.parent = o(e.parent)), e;
    }
    _getDimension() {
      return this._element.classList.contains("collapse-horizontal")
        ? "width"
        : "height";
    }
    _initializeChildren() {
      if (!this._config.parent) return;
      const e = this._getFirstLevelChildren(ue);
      for (const t of e) {
        const e = z.getElementFromSelector(t);
        e && this._addAriaAndCollapsedClass([t], this._isShown(e));
      }
    }
    _getFirstLevelChildren(e) {
      const t = z.find(":scope .collapse .collapse", this._config.parent);
      return z.find(e, this._config.parent).filter((e) => !t.includes(e));
    }
    _addAriaAndCollapsedClass(e, t) {
      if (e.length)
        for (const n of e)
          n.classList.toggle("collapsed", !t),
            n.setAttribute("aria-expanded", t);
    }
    static jQueryInterface(e) {
      const t = {};
      return (
        "string" == typeof e && /show|hide/.test(e) && (t.toggle = !1),
        this.each(function () {
          const n = fe.getOrCreateInstance(this, t);
          if ("string" == typeof e) {
            if (void 0 === n[e]) throw new TypeError(`No method named "${e}"`);
            n[e]();
          }
        })
      );
    }
  }
  j.on(document, "click.bs.collapse.data-api", ue, function (e) {
    ("A" === e.target.tagName ||
      (e.delegateTarget && "A" === e.delegateTarget.tagName)) &&
      e.preventDefault();
    for (const e of z.getMultipleElementsFromSelector(this))
      fe.getOrCreateInstance(e, { toggle: !1 }).toggle();
  }),
    g(fe);
  var pe = "top",
    ge = "bottom",
    me = "right",
    be = "left",
    _e = "auto",
    ye = [pe, ge, me, be],
    ve = "start",
    we = "end",
    Ae = "clippingParents",
    Ee = "viewport",
    xe = "popper",
    ke = "reference",
    Se = ye.reduce(function (e, t) {
      return e.concat([t + "-" + ve, t + "-" + we]);
    }, []),
    Te = [].concat(ye, [_e]).reduce(function (e, t) {
      return e.concat([t, t + "-" + ve, t + "-" + we]);
    }, []),
    Pe = "beforeRead",
    Ce = "afterRead",
    Oe = "beforeMain",
    Le = "afterMain",
    Fe = "beforeWrite",
    De = "afterWrite",
    je = [Pe, "read", Ce, Oe, "main", Le, Fe, "write", De];
  function Ie(e) {
    return e ? (e.nodeName || "").toLowerCase() : null;
  }
  function Me(e) {
    if (null == e) return window;
    if ("[object Window]" !== e.toString()) {
      var t = e.ownerDocument;
      return (t && t.defaultView) || window;
    }
    return e;
  }
  function Ne(e) {
    return e instanceof Me(e).Element || e instanceof Element;
  }
  function $e(e) {
    return e instanceof Me(e).HTMLElement || e instanceof HTMLElement;
  }
  function He(e) {
    return (
      "undefined" != typeof ShadowRoot &&
      (e instanceof Me(e).ShadowRoot || e instanceof ShadowRoot)
    );
  }
  const Be = {
    name: "applyStyles",
    enabled: !0,
    phase: "write",
    fn: function (e) {
      var t = e.state;
      Object.keys(t.elements).forEach(function (e) {
        var n = t.styles[e] || {},
          i = t.attributes[e] || {},
          r = t.elements[e];
        $e(r) &&
          Ie(r) &&
          (Object.assign(r.style, n),
          Object.keys(i).forEach(function (e) {
            var t = i[e];
            !1 === t
              ? r.removeAttribute(e)
              : r.setAttribute(e, !0 === t ? "" : t);
          }));
      });
    },
    effect: function (e) {
      var t = e.state,
        n = {
          popper: {
            position: t.options.strategy,
            left: "0",
            top: "0",
            margin: "0",
          },
          arrow: { position: "absolute" },
          reference: {},
        };
      return (
        Object.assign(t.elements.popper.style, n.popper),
        (t.styles = n),
        t.elements.arrow && Object.assign(t.elements.arrow.style, n.arrow),
        function () {
          Object.keys(t.elements).forEach(function (e) {
            var i = t.elements[e],
              r = t.attributes[e] || {},
              s = Object.keys(
                t.styles.hasOwnProperty(e) ? t.styles[e] : n[e]
              ).reduce(function (e, t) {
                return (e[t] = ""), e;
              }, {});
            $e(i) &&
              Ie(i) &&
              (Object.assign(i.style, s),
              Object.keys(r).forEach(function (e) {
                i.removeAttribute(e);
              }));
          });
        }
      );
    },
    requires: ["computeStyles"],
  };
  function Ve(e) {
    return e.split("-")[0];
  }
  var ze = Math.max,
    Re = Math.min,
    We = Math.round;
  function qe() {
    var e = navigator.userAgentData;
    return null != e && e.brands && Array.isArray(e.brands)
      ? e.brands
          .map(function (e) {
            return e.brand + "/" + e.version;
          })
          .join(" ")
      : navigator.userAgent;
  }
  function Ue() {
    return !/^((?!chrome|android).)*safari/i.test(qe());
  }
  function Ye(e, t, n) {
    void 0 === t && (t = !1), void 0 === n && (n = !1);
    var i = e.getBoundingClientRect(),
      r = 1,
      s = 1;
    t &&
      $e(e) &&
      ((r = (e.offsetWidth > 0 && We(i.width) / e.offsetWidth) || 1),
      (s = (e.offsetHeight > 0 && We(i.height) / e.offsetHeight) || 1));
    var o = (Ne(e) ? Me(e) : window).visualViewport,
      a = !Ue() && n,
      l = (i.left + (a && o ? o.offsetLeft : 0)) / r,
      c = (i.top + (a && o ? o.offsetTop : 0)) / s,
      u = i.width / r,
      d = i.height / s;
    return {
      width: u,
      height: d,
      top: c,
      right: l + u,
      bottom: c + d,
      left: l,
      x: l,
      y: c,
    };
  }
  function Xe(e) {
    var t = Ye(e),
      n = e.offsetWidth,
      i = e.offsetHeight;
    return (
      Math.abs(t.width - n) <= 1 && (n = t.width),
      Math.abs(t.height - i) <= 1 && (i = t.height),
      { x: e.offsetLeft, y: e.offsetTop, width: n, height: i }
    );
  }
  function Ke(e, t) {
    var n = t.getRootNode && t.getRootNode();
    if (e.contains(t)) return !0;
    if (n && He(n)) {
      var i = t;
      do {
        if (i && e.isSameNode(i)) return !0;
        i = i.parentNode || i.host;
      } while (i);
    }
    return !1;
  }
  function Qe(e) {
    return Me(e).getComputedStyle(e);
  }
  function Ze(e) {
    return ["table", "td", "th"].indexOf(Ie(e)) >= 0;
  }
  function Je(e) {
    return (
      (Ne(e) ? e.ownerDocument : e.document) || window.document
    ).documentElement;
  }
  function Ge(e) {
    return "html" === Ie(e)
      ? e
      : e.assignedSlot || e.parentNode || (He(e) ? e.host : null) || Je(e);
  }
  function et(e) {
    return $e(e) && "fixed" !== Qe(e).position ? e.offsetParent : null;
  }
  function tt(e) {
    for (var t = Me(e), n = et(e); n && Ze(n) && "static" === Qe(n).position; )
      n = et(n);
    return n &&
      ("html" === Ie(n) || ("body" === Ie(n) && "static" === Qe(n).position))
      ? t
      : n ||
          (function (e) {
            var t = /firefox/i.test(qe());
            if (/Trident/i.test(qe()) && $e(e) && "fixed" === Qe(e).position)
              return null;
            var n = Ge(e);
            for (
              He(n) && (n = n.host);
              $e(n) && ["html", "body"].indexOf(Ie(n)) < 0;

            ) {
              var i = Qe(n);
              if (
                "none" !== i.transform ||
                "none" !== i.perspective ||
                "paint" === i.contain ||
                -1 !== ["transform", "perspective"].indexOf(i.willChange) ||
                (t && "filter" === i.willChange) ||
                (t && i.filter && "none" !== i.filter)
              )
                return n;
              n = n.parentNode;
            }
            return null;
          })(e) ||
          t;
  }
  function nt(e) {
    return ["top", "bottom"].indexOf(e) >= 0 ? "x" : "y";
  }
  function it(e, t, n) {
    return ze(e, Re(t, n));
  }
  function rt(e) {
    return Object.assign({}, { top: 0, right: 0, bottom: 0, left: 0 }, e);
  }
  function st(e, t) {
    return t.reduce(function (t, n) {
      return (t[n] = e), t;
    }, {});
  }
  const ot = {
    name: "arrow",
    enabled: !0,
    phase: "main",
    fn: function (e) {
      var t,
        n = e.state,
        i = e.name,
        r = e.options,
        s = n.elements.arrow,
        o = n.modifiersData.popperOffsets,
        a = Ve(n.placement),
        l = nt(a),
        c = [be, me].indexOf(a) >= 0 ? "height" : "width";
      if (s && o) {
        var u = (function (e, t) {
            return rt(
              "number" !=
                typeof (e =
                  "function" == typeof e
                    ? e(Object.assign({}, t.rects, { placement: t.placement }))
                    : e)
                ? e
                : st(e, ye)
            );
          })(r.padding, n),
          d = Xe(s),
          h = "y" === l ? pe : be,
          f = "y" === l ? ge : me,
          p =
            n.rects.reference[c] +
            n.rects.reference[l] -
            o[l] -
            n.rects.popper[c],
          g = o[l] - n.rects.reference[l],
          m = tt(s),
          b = m ? ("y" === l ? m.clientHeight || 0 : m.clientWidth || 0) : 0,
          _ = p / 2 - g / 2,
          y = u[h],
          v = b - d[c] - u[f],
          w = b / 2 - d[c] / 2 + _,
          A = it(y, w, v),
          E = l;
        n.modifiersData[i] = (((t = {})[E] = A), (t.centerOffset = A - w), t);
      }
    },
    effect: function (e) {
      var t = e.state,
        n = e.options.element,
        i = void 0 === n ? "[data-popper-arrow]" : n;
      null != i &&
        ("string" != typeof i || (i = t.elements.popper.querySelector(i))) &&
        Ke(t.elements.popper, i) &&
        (t.elements.arrow = i);
    },
    requires: ["popperOffsets"],
    requiresIfExists: ["preventOverflow"],
  };
  function at(e) {
    return e.split("-")[1];
  }
  var lt = { top: "auto", right: "auto", bottom: "auto", left: "auto" };
  function ct(e) {
    var t,
      n = e.popper,
      i = e.popperRect,
      r = e.placement,
      s = e.variation,
      o = e.offsets,
      a = e.position,
      l = e.gpuAcceleration,
      c = e.adaptive,
      u = e.roundOffsets,
      d = e.isFixed,
      h = o.x,
      f = void 0 === h ? 0 : h,
      p = o.y,
      g = void 0 === p ? 0 : p,
      m = "function" == typeof u ? u({ x: f, y: g }) : { x: f, y: g };
    (f = m.x), (g = m.y);
    var b = o.hasOwnProperty("x"),
      _ = o.hasOwnProperty("y"),
      y = be,
      v = pe,
      w = window;
    if (c) {
      var A = tt(n),
        E = "clientHeight",
        x = "clientWidth";
      A === Me(n) &&
        "static" !== Qe((A = Je(n))).position &&
        "absolute" === a &&
        ((E = "scrollHeight"), (x = "scrollWidth")),
        (r === pe || ((r === be || r === me) && s === we)) &&
          ((v = ge),
          (g -=
            (d && A === w && w.visualViewport
              ? w.visualViewport.height
              : A[E]) - i.height),
          (g *= l ? 1 : -1)),
        (r !== be && ((r !== pe && r !== ge) || s !== we)) ||
          ((y = me),
          (f -=
            (d && A === w && w.visualViewport ? w.visualViewport.width : A[x]) -
            i.width),
          (f *= l ? 1 : -1));
    }
    var k,
      S = Object.assign({ position: a }, c && lt),
      T =
        !0 === u
          ? (function (e, t) {
              var n = e.x,
                i = e.y,
                r = t.devicePixelRatio || 1;
              return { x: We(n * r) / r || 0, y: We(i * r) / r || 0 };
            })({ x: f, y: g }, Me(n))
          : { x: f, y: g };
    return (
      (f = T.x),
      (g = T.y),
      l
        ? Object.assign(
            {},
            S,
            (((k = {})[v] = _ ? "0" : ""),
            (k[y] = b ? "0" : ""),
            (k.transform =
              (w.devicePixelRatio || 1) <= 1
                ? "translate(" + f + "px, " + g + "px)"
                : "translate3d(" + f + "px, " + g + "px, 0)"),
            k)
          )
        : Object.assign(
            {},
            S,
            (((t = {})[v] = _ ? g + "px" : ""),
            (t[y] = b ? f + "px" : ""),
            (t.transform = ""),
            t)
          )
    );
  }
  const ut = {
    name: "computeStyles",
    enabled: !0,
    phase: "beforeWrite",
    fn: function (e) {
      var t = e.state,
        n = e.options,
        i = n.gpuAcceleration,
        r = void 0 === i || i,
        s = n.adaptive,
        o = void 0 === s || s,
        a = n.roundOffsets,
        l = void 0 === a || a,
        c = {
          placement: Ve(t.placement),
          variation: at(t.placement),
          popper: t.elements.popper,
          popperRect: t.rects.popper,
          gpuAcceleration: r,
          isFixed: "fixed" === t.options.strategy,
        };
      null != t.modifiersData.popperOffsets &&
        (t.styles.popper = Object.assign(
          {},
          t.styles.popper,
          ct(
            Object.assign({}, c, {
              offsets: t.modifiersData.popperOffsets,
              position: t.options.strategy,
              adaptive: o,
              roundOffsets: l,
            })
          )
        )),
        null != t.modifiersData.arrow &&
          (t.styles.arrow = Object.assign(
            {},
            t.styles.arrow,
            ct(
              Object.assign({}, c, {
                offsets: t.modifiersData.arrow,
                position: "absolute",
                adaptive: !1,
                roundOffsets: l,
              })
            )
          )),
        (t.attributes.popper = Object.assign({}, t.attributes.popper, {
          "data-popper-placement": t.placement,
        }));
    },
    data: {},
  };
  var dt = { passive: !0 };
  const ht = {
    name: "eventListeners",
    enabled: !0,
    phase: "write",
    fn: function () {},
    effect: function (e) {
      var t = e.state,
        n = e.instance,
        i = e.options,
        r = i.scroll,
        s = void 0 === r || r,
        o = i.resize,
        a = void 0 === o || o,
        l = Me(t.elements.popper),
        c = [].concat(t.scrollParents.reference, t.scrollParents.popper);
      return (
        s &&
          c.forEach(function (e) {
            e.addEventListener("scroll", n.update, dt);
          }),
        a && l.addEventListener("resize", n.update, dt),
        function () {
          s &&
            c.forEach(function (e) {
              e.removeEventListener("scroll", n.update, dt);
            }),
            a && l.removeEventListener("resize", n.update, dt);
        }
      );
    },
    data: {},
  };
  var ft = { left: "right", right: "left", bottom: "top", top: "bottom" };
  function pt(e) {
    return e.replace(/left|right|bottom|top/g, function (e) {
      return ft[e];
    });
  }
  var gt = { start: "end", end: "start" };
  function mt(e) {
    return e.replace(/start|end/g, function (e) {
      return gt[e];
    });
  }
  function bt(e) {
    var t = Me(e);
    return { scrollLeft: t.pageXOffset, scrollTop: t.pageYOffset };
  }
  function _t(e) {
    return Ye(Je(e)).left + bt(e).scrollLeft;
  }
  function yt(e) {
    var t = Qe(e),
      n = t.overflow,
      i = t.overflowX,
      r = t.overflowY;
    return /auto|scroll|overlay|hidden/.test(n + r + i);
  }
  function vt(e, t) {
    var n;
    void 0 === t && (t = []);
    var i = (function e(t) {
        return ["html", "body", "#document"].indexOf(Ie(t)) >= 0
          ? t.ownerDocument.body
          : $e(t) && yt(t)
          ? t
          : e(Ge(t));
      })(e),
      r = i === (null == (n = e.ownerDocument) ? void 0 : n.body),
      s = Me(i),
      o = r ? [s].concat(s.visualViewport || [], yt(i) ? i : []) : i,
      a = t.concat(o);
    return r ? a : a.concat(vt(Ge(o)));
  }
  function wt(e) {
    return Object.assign({}, e, {
      left: e.x,
      top: e.y,
      right: e.x + e.width,
      bottom: e.y + e.height,
    });
  }
  function At(e, t, n) {
    return t === Ee
      ? wt(
          (function (e, t) {
            var n = Me(e),
              i = Je(e),
              r = n.visualViewport,
              s = i.clientWidth,
              o = i.clientHeight,
              a = 0,
              l = 0;
            if (r) {
              (s = r.width), (o = r.height);
              var c = Ue();
              (c || (!c && "fixed" === t)) &&
                ((a = r.offsetLeft), (l = r.offsetTop));
            }
            return { width: s, height: o, x: a + _t(e), y: l };
          })(e, n)
        )
      : Ne(t)
      ? (function (e, t) {
          var n = Ye(e, !1, "fixed" === t);
          return (
            (n.top = n.top + e.clientTop),
            (n.left = n.left + e.clientLeft),
            (n.bottom = n.top + e.clientHeight),
            (n.right = n.left + e.clientWidth),
            (n.width = e.clientWidth),
            (n.height = e.clientHeight),
            (n.x = n.left),
            (n.y = n.top),
            n
          );
        })(t, n)
      : wt(
          (function (e) {
            var t,
              n = Je(e),
              i = bt(e),
              r = null == (t = e.ownerDocument) ? void 0 : t.body,
              s = ze(
                n.scrollWidth,
                n.clientWidth,
                r ? r.scrollWidth : 0,
                r ? r.clientWidth : 0
              ),
              o = ze(
                n.scrollHeight,
                n.clientHeight,
                r ? r.scrollHeight : 0,
                r ? r.clientHeight : 0
              ),
              a = -i.scrollLeft + _t(e),
              l = -i.scrollTop;
            return (
              "rtl" === Qe(r || n).direction &&
                (a += ze(n.clientWidth, r ? r.clientWidth : 0) - s),
              { width: s, height: o, x: a, y: l }
            );
          })(Je(e))
        );
  }
  function Et(e) {
    var t,
      n = e.reference,
      i = e.element,
      r = e.placement,
      s = r ? Ve(r) : null,
      o = r ? at(r) : null,
      a = n.x + n.width / 2 - i.width / 2,
      l = n.y + n.height / 2 - i.height / 2;
    switch (s) {
      case pe:
        t = { x: a, y: n.y - i.height };
        break;
      case ge:
        t = { x: a, y: n.y + n.height };
        break;
      case me:
        t = { x: n.x + n.width, y: l };
        break;
      case be:
        t = { x: n.x - i.width, y: l };
        break;
      default:
        t = { x: n.x, y: n.y };
    }
    var c = s ? nt(s) : null;
    if (null != c) {
      var u = "y" === c ? "height" : "width";
      switch (o) {
        case ve:
          t[c] = t[c] - (n[u] / 2 - i[u] / 2);
          break;
        case we:
          t[c] = t[c] + (n[u] / 2 - i[u] / 2);
      }
    }
    return t;
  }
  function xt(e, t) {
    void 0 === t && (t = {});
    var n = t,
      i = n.placement,
      r = void 0 === i ? e.placement : i,
      s = n.strategy,
      o = void 0 === s ? e.strategy : s,
      a = n.boundary,
      l = void 0 === a ? Ae : a,
      c = n.rootBoundary,
      u = void 0 === c ? Ee : c,
      d = n.elementContext,
      h = void 0 === d ? xe : d,
      f = n.altBoundary,
      p = void 0 !== f && f,
      g = n.padding,
      m = void 0 === g ? 0 : g,
      b = rt("number" != typeof m ? m : st(m, ye)),
      _ = h === xe ? ke : xe,
      y = e.rects.popper,
      v = e.elements[p ? _ : h],
      w = (function (e, t, n, i) {
        var r =
            "clippingParents" === t
              ? (function (e) {
                  var t = vt(Ge(e)),
                    n =
                      ["absolute", "fixed"].indexOf(Qe(e).position) >= 0 &&
                      $e(e)
                        ? tt(e)
                        : e;
                  return Ne(n)
                    ? t.filter(function (e) {
                        return Ne(e) && Ke(e, n) && "body" !== Ie(e);
                      })
                    : [];
                })(e)
              : [].concat(t),
          s = [].concat(r, [n]),
          o = s[0],
          a = s.reduce(function (t, n) {
            var r = At(e, n, i);
            return (
              (t.top = ze(r.top, t.top)),
              (t.right = Re(r.right, t.right)),
              (t.bottom = Re(r.bottom, t.bottom)),
              (t.left = ze(r.left, t.left)),
              t
            );
          }, At(e, o, i));
        return (
          (a.width = a.right - a.left),
          (a.height = a.bottom - a.top),
          (a.x = a.left),
          (a.y = a.top),
          a
        );
      })(Ne(v) ? v : v.contextElement || Je(e.elements.popper), l, u, o),
      A = Ye(e.elements.reference),
      E = Et({ reference: A, element: y, strategy: "absolute", placement: r }),
      x = wt(Object.assign({}, y, E)),
      k = h === xe ? x : A,
      S = {
        top: w.top - k.top + b.top,
        bottom: k.bottom - w.bottom + b.bottom,
        left: w.left - k.left + b.left,
        right: k.right - w.right + b.right,
      },
      T = e.modifiersData.offset;
    if (h === xe && T) {
      var P = T[r];
      Object.keys(S).forEach(function (e) {
        var t = [me, ge].indexOf(e) >= 0 ? 1 : -1,
          n = [pe, ge].indexOf(e) >= 0 ? "y" : "x";
        S[e] += P[n] * t;
      });
    }
    return S;
  }
  const kt = {
    name: "flip",
    enabled: !0,
    phase: "main",
    fn: function (e) {
      var t = e.state,
        n = e.options,
        i = e.name;
      if (!t.modifiersData[i]._skip) {
        for (
          var r = n.mainAxis,
            s = void 0 === r || r,
            o = n.altAxis,
            a = void 0 === o || o,
            l = n.fallbackPlacements,
            c = n.padding,
            u = n.boundary,
            d = n.rootBoundary,
            h = n.altBoundary,
            f = n.flipVariations,
            p = void 0 === f || f,
            g = n.allowedAutoPlacements,
            m = t.options.placement,
            b = Ve(m),
            _ =
              l ||
              (b !== m && p
                ? (function (e) {
                    if (Ve(e) === _e) return [];
                    var t = pt(e);
                    return [mt(e), t, mt(t)];
                  })(m)
                : [pt(m)]),
            y = [m].concat(_).reduce(function (e, n) {
              return e.concat(
                Ve(n) === _e
                  ? (function (e, t) {
                      void 0 === t && (t = {});
                      var n = t,
                        i = n.placement,
                        r = n.boundary,
                        s = n.rootBoundary,
                        o = n.padding,
                        a = n.flipVariations,
                        l = n.allowedAutoPlacements,
                        c = void 0 === l ? Te : l,
                        u = at(i),
                        d = u
                          ? a
                            ? Se
                            : Se.filter(function (e) {
                                return at(e) === u;
                              })
                          : ye,
                        h = d.filter(function (e) {
                          return c.indexOf(e) >= 0;
                        });
                      0 === h.length && (h = d);
                      var f = h.reduce(function (t, n) {
                        return (
                          (t[n] = xt(e, {
                            placement: n,
                            boundary: r,
                            rootBoundary: s,
                            padding: o,
                          })[Ve(n)]),
                          t
                        );
                      }, {});
                      return Object.keys(f).sort(function (e, t) {
                        return f[e] - f[t];
                      });
                    })(t, {
                      placement: n,
                      boundary: u,
                      rootBoundary: d,
                      padding: c,
                      flipVariations: p,
                      allowedAutoPlacements: g,
                    })
                  : n
              );
            }, []),
            v = t.rects.reference,
            w = t.rects.popper,
            A = new Map(),
            E = !0,
            x = y[0],
            k = 0;
          k < y.length;
          k++
        ) {
          var S = y[k],
            T = Ve(S),
            P = at(S) === ve,
            C = [pe, ge].indexOf(T) >= 0,
            O = C ? "width" : "height",
            L = xt(t, {
              placement: S,
              boundary: u,
              rootBoundary: d,
              altBoundary: h,
              padding: c,
            }),
            F = C ? (P ? me : be) : P ? ge : pe;
          v[O] > w[O] && (F = pt(F));
          var D = pt(F),
            j = [];
          if (
            (s && j.push(L[T] <= 0),
            a && j.push(L[F] <= 0, L[D] <= 0),
            j.every(function (e) {
              return e;
            }))
          ) {
            (x = S), (E = !1);
            break;
          }
          A.set(S, j);
        }
        if (E)
          for (
            var I = function (e) {
                var t = y.find(function (t) {
                  var n = A.get(t);
                  if (n)
                    return n.slice(0, e).every(function (e) {
                      return e;
                    });
                });
                if (t) return (x = t), "break";
              },
              M = p ? 3 : 1;
            M > 0 && "break" !== I(M);
            M--
          );
        t.placement !== x &&
          ((t.modifiersData[i]._skip = !0), (t.placement = x), (t.reset = !0));
      }
    },
    requiresIfExists: ["offset"],
    data: { _skip: !1 },
  };
  function St(e, t, n) {
    return (
      void 0 === n && (n = { x: 0, y: 0 }),
      {
        top: e.top - t.height - n.y,
        right: e.right - t.width + n.x,
        bottom: e.bottom - t.height + n.y,
        left: e.left - t.width - n.x,
      }
    );
  }
  function Tt(e) {
    return [pe, me, ge, be].some(function (t) {
      return e[t] >= 0;
    });
  }
  const Pt = {
      name: "hide",
      enabled: !0,
      phase: "main",
      requiresIfExists: ["preventOverflow"],
      fn: function (e) {
        var t = e.state,
          n = e.name,
          i = t.rects.reference,
          r = t.rects.popper,
          s = t.modifiersData.preventOverflow,
          o = xt(t, { elementContext: "reference" }),
          a = xt(t, { altBoundary: !0 }),
          l = St(o, i),
          c = St(a, r, s),
          u = Tt(l),
          d = Tt(c);
        (t.modifiersData[n] = {
          referenceClippingOffsets: l,
          popperEscapeOffsets: c,
          isReferenceHidden: u,
          hasPopperEscaped: d,
        }),
          (t.attributes.popper = Object.assign({}, t.attributes.popper, {
            "data-popper-reference-hidden": u,
            "data-popper-escaped": d,
          }));
      },
    },
    Ct = {
      name: "offset",
      enabled: !0,
      phase: "main",
      requires: ["popperOffsets"],
      fn: function (e) {
        var t = e.state,
          n = e.options,
          i = e.name,
          r = n.offset,
          s = void 0 === r ? [0, 0] : r,
          o = Te.reduce(function (e, n) {
            return (
              (e[n] = (function (e, t, n) {
                var i = Ve(e),
                  r = [be, pe].indexOf(i) >= 0 ? -1 : 1,
                  s =
                    "function" == typeof n
                      ? n(Object.assign({}, t, { placement: e }))
                      : n,
                  o = s[0],
                  a = s[1];
                return (
                  (o = o || 0),
                  (a = (a || 0) * r),
                  [be, me].indexOf(i) >= 0 ? { x: a, y: o } : { x: o, y: a }
                );
              })(n, t.rects, s)),
              e
            );
          }, {}),
          a = o[t.placement],
          l = a.x,
          c = a.y;
        null != t.modifiersData.popperOffsets &&
          ((t.modifiersData.popperOffsets.x += l),
          (t.modifiersData.popperOffsets.y += c)),
          (t.modifiersData[i] = o);
      },
    },
    Ot = {
      name: "popperOffsets",
      enabled: !0,
      phase: "read",
      fn: function (e) {
        var t = e.state,
          n = e.name;
        t.modifiersData[n] = Et({
          reference: t.rects.reference,
          element: t.rects.popper,
          strategy: "absolute",
          placement: t.placement,
        });
      },
      data: {},
    },
    Lt = {
      name: "preventOverflow",
      enabled: !0,
      phase: "main",
      fn: function (e) {
        var t = e.state,
          n = e.options,
          i = e.name,
          r = n.mainAxis,
          s = void 0 === r || r,
          o = n.altAxis,
          a = void 0 !== o && o,
          l = n.boundary,
          c = n.rootBoundary,
          u = n.altBoundary,
          d = n.padding,
          h = n.tether,
          f = void 0 === h || h,
          p = n.tetherOffset,
          g = void 0 === p ? 0 : p,
          m = xt(t, {
            boundary: l,
            rootBoundary: c,
            padding: d,
            altBoundary: u,
          }),
          b = Ve(t.placement),
          _ = at(t.placement),
          y = !_,
          v = nt(b),
          w = "x" === v ? "y" : "x",
          A = t.modifiersData.popperOffsets,
          E = t.rects.reference,
          x = t.rects.popper,
          k =
            "function" == typeof g
              ? g(Object.assign({}, t.rects, { placement: t.placement }))
              : g,
          S =
            "number" == typeof k
              ? { mainAxis: k, altAxis: k }
              : Object.assign({ mainAxis: 0, altAxis: 0 }, k),
          T = t.modifiersData.offset
            ? t.modifiersData.offset[t.placement]
            : null,
          P = { x: 0, y: 0 };
        if (A) {
          if (s) {
            var C,
              O = "y" === v ? pe : be,
              L = "y" === v ? ge : me,
              F = "y" === v ? "height" : "width",
              D = A[v],
              j = D + m[O],
              I = D - m[L],
              M = f ? -x[F] / 2 : 0,
              N = _ === ve ? E[F] : x[F],
              $ = _ === ve ? -x[F] : -E[F],
              H = t.elements.arrow,
              B = f && H ? Xe(H) : { width: 0, height: 0 },
              V = t.modifiersData["arrow#persistent"]
                ? t.modifiersData["arrow#persistent"].padding
                : { top: 0, right: 0, bottom: 0, left: 0 },
              z = V[O],
              R = V[L],
              W = it(0, E[F], B[F]),
              q = y
                ? E[F] / 2 - M - W - z - S.mainAxis
                : N - W - z - S.mainAxis,
              U = y
                ? -E[F] / 2 + M + W + R + S.mainAxis
                : $ + W + R + S.mainAxis,
              Y = t.elements.arrow && tt(t.elements.arrow),
              X = Y ? ("y" === v ? Y.clientTop || 0 : Y.clientLeft || 0) : 0,
              K = null != (C = null == T ? void 0 : T[v]) ? C : 0,
              Q = D + U - K,
              Z = it(f ? Re(j, D + q - K - X) : j, D, f ? ze(I, Q) : I);
            (A[v] = Z), (P[v] = Z - D);
          }
          if (a) {
            var J,
              G = "x" === v ? pe : be,
              ee = "x" === v ? ge : me,
              te = A[w],
              ne = "y" === w ? "height" : "width",
              ie = te + m[G],
              re = te - m[ee],
              se = -1 !== [pe, be].indexOf(b),
              oe = null != (J = null == T ? void 0 : T[w]) ? J : 0,
              ae = se ? ie : te - E[ne] - x[ne] - oe + S.altAxis,
              le = se ? te + E[ne] + x[ne] - oe - S.altAxis : re,
              ce =
                f && se
                  ? (function (e, t, n) {
                      var i = it(e, t, n);
                      return i > n ? n : i;
                    })(ae, te, le)
                  : it(f ? ae : ie, te, f ? le : re);
            (A[w] = ce), (P[w] = ce - te);
          }
          t.modifiersData[i] = P;
        }
      },
      requiresIfExists: ["offset"],
    };
  function Ft(e, t, n) {
    void 0 === n && (n = !1);
    var i,
      r,
      s = $e(t),
      o =
        $e(t) &&
        (function (e) {
          var t = e.getBoundingClientRect(),
            n = We(t.width) / e.offsetWidth || 1,
            i = We(t.height) / e.offsetHeight || 1;
          return 1 !== n || 1 !== i;
        })(t),
      a = Je(t),
      l = Ye(e, o, n),
      c = { scrollLeft: 0, scrollTop: 0 },
      u = { x: 0, y: 0 };
    return (
      (s || (!s && !n)) &&
        (("body" !== Ie(t) || yt(a)) &&
          (c =
            (i = t) !== Me(i) && $e(i)
              ? { scrollLeft: (r = i).scrollLeft, scrollTop: r.scrollTop }
              : bt(i)),
        $e(t)
          ? (((u = Ye(t, !0)).x += t.clientLeft), (u.y += t.clientTop))
          : a && (u.x = _t(a))),
      {
        x: l.left + c.scrollLeft - u.x,
        y: l.top + c.scrollTop - u.y,
        width: l.width,
        height: l.height,
      }
    );
  }
  function Dt(e) {
    var t = new Map(),
      n = new Set(),
      i = [];
    return (
      e.forEach(function (e) {
        t.set(e.name, e);
      }),
      e.forEach(function (e) {
        n.has(e.name) ||
          (function e(r) {
            n.add(r.name),
              []
                .concat(r.requires || [], r.requiresIfExists || [])
                .forEach(function (i) {
                  if (!n.has(i)) {
                    var r = t.get(i);
                    r && e(r);
                  }
                }),
              i.push(r);
          })(e);
      }),
      i
    );
  }
  var jt = { placement: "bottom", modifiers: [], strategy: "absolute" };
  function It() {
    for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++)
      t[n] = arguments[n];
    return !t.some(function (e) {
      return !(e && "function" == typeof e.getBoundingClientRect);
    });
  }
  function Mt(e) {
    void 0 === e && (e = {});
    var t = e,
      n = t.defaultModifiers,
      i = void 0 === n ? [] : n,
      r = t.defaultOptions,
      s = void 0 === r ? jt : r;
    return function (e, t, n) {
      void 0 === n && (n = s);
      var r,
        o,
        a = {
          placement: "bottom",
          orderedModifiers: [],
          options: Object.assign({}, jt, s),
          modifiersData: {},
          elements: { reference: e, popper: t },
          attributes: {},
          styles: {},
        },
        l = [],
        c = !1,
        u = {
          state: a,
          setOptions: function (n) {
            var r = "function" == typeof n ? n(a.options) : n;
            d(),
              (a.options = Object.assign({}, s, a.options, r)),
              (a.scrollParents = {
                reference: Ne(e)
                  ? vt(e)
                  : e.contextElement
                  ? vt(e.contextElement)
                  : [],
                popper: vt(t),
              });
            var o,
              c,
              h = (function (e) {
                var t = Dt(e);
                return je.reduce(function (e, n) {
                  return e.concat(
                    t.filter(function (e) {
                      return e.phase === n;
                    })
                  );
                }, []);
              })(
                ((o = [].concat(i, a.options.modifiers)),
                (c = o.reduce(function (e, t) {
                  var n = e[t.name];
                  return (
                    (e[t.name] = n
                      ? Object.assign({}, n, t, {
                          options: Object.assign({}, n.options, t.options),
                          data: Object.assign({}, n.data, t.data),
                        })
                      : t),
                    e
                  );
                }, {})),
                Object.keys(c).map(function (e) {
                  return c[e];
                }))
              );
            return (
              (a.orderedModifiers = h.filter(function (e) {
                return e.enabled;
              })),
              a.orderedModifiers.forEach(function (e) {
                var t = e.name,
                  n = e.options,
                  i = void 0 === n ? {} : n,
                  r = e.effect;
                if ("function" == typeof r) {
                  var s = r({ state: a, name: t, instance: u, options: i });
                  l.push(s || function () {});
                }
              }),
              u.update()
            );
          },
          forceUpdate: function () {
            if (!c) {
              var e = a.elements,
                t = e.reference,
                n = e.popper;
              if (It(t, n)) {
                (a.rects = {
                  reference: Ft(t, tt(n), "fixed" === a.options.strategy),
                  popper: Xe(n),
                }),
                  (a.reset = !1),
                  (a.placement = a.options.placement),
                  a.orderedModifiers.forEach(function (e) {
                    return (a.modifiersData[e.name] = Object.assign(
                      {},
                      e.data
                    ));
                  });
                for (var i = 0; i < a.orderedModifiers.length; i++)
                  if (!0 !== a.reset) {
                    var r = a.orderedModifiers[i],
                      s = r.fn,
                      o = r.options,
                      l = void 0 === o ? {} : o,
                      d = r.name;
                    "function" == typeof s &&
                      (a =
                        s({ state: a, options: l, name: d, instance: u }) || a);
                  } else (a.reset = !1), (i = -1);
              }
            }
          },
          update:
            ((r = function () {
              return new Promise(function (e) {
                u.forceUpdate(), e(a);
              });
            }),
            function () {
              return (
                o ||
                  (o = new Promise(function (e) {
                    Promise.resolve().then(function () {
                      (o = void 0), e(r());
                    });
                  })),
                o
              );
            }),
          destroy: function () {
            d(), (c = !0);
          },
        };
      if (!It(e, t)) return u;
      function d() {
        l.forEach(function (e) {
          return e();
        }),
          (l = []);
      }
      return (
        u.setOptions(n).then(function (e) {
          !c && n.onFirstUpdate && n.onFirstUpdate(e);
        }),
        u
      );
    };
  }
  var Nt = Mt(),
    $t = Mt({ defaultModifiers: [ht, Ot, ut, Be] }),
    Ht = Mt({ defaultModifiers: [ht, Ot, ut, Be, Ct, kt, Lt, ot, Pt] });
  const Bt = Object.freeze(
      Object.defineProperty(
        {
          __proto__: null,
          afterMain: Le,
          afterRead: Ce,
          afterWrite: De,
          applyStyles: Be,
          arrow: ot,
          auto: _e,
          basePlacements: ye,
          beforeMain: Oe,
          beforeRead: Pe,
          beforeWrite: Fe,
          bottom: ge,
          clippingParents: Ae,
          computeStyles: ut,
          createPopper: Ht,
          createPopperBase: Nt,
          createPopperLite: $t,
          detectOverflow: xt,
          end: we,
          eventListeners: ht,
          flip: kt,
          hide: Pt,
          left: be,
          main: "main",
          modifierPhases: je,
          offset: Ct,
          placements: Te,
          popper: xe,
          popperGenerator: Mt,
          popperOffsets: Ot,
          preventOverflow: Lt,
          read: "read",
          reference: ke,
          right: me,
          start: ve,
          top: pe,
          variationPlacements: Se,
          viewport: Ee,
          write: "write",
        },
        Symbol.toStringTag,
        { value: "Module" }
      )
    ),
    Vt = "dropdown",
    zt = "ArrowUp",
    Rt = "ArrowDown",
    Wt = "click.bs.dropdown.data-api",
    qt = "keydown.bs.dropdown.data-api",
    Ut = "show",
    Yt = '[data-bs-toggle="dropdown"]:not(.disabled):not(:disabled)',
    Xt = ".dropdown-menu",
    Kt = p() ? "top-end" : "top-start",
    Qt = p() ? "top-start" : "top-end",
    Zt = p() ? "bottom-end" : "bottom-start",
    Jt = p() ? "bottom-start" : "bottom-end",
    Gt = p() ? "left-start" : "right-start",
    en = p() ? "right-start" : "left-start",
    tn = {
      autoClose: !0,
      boundary: "clippingParents",
      display: "dynamic",
      offset: [0, 2],
      popperConfig: null,
      reference: "toggle",
    },
    nn = {
      autoClose: "(boolean|string)",
      boundary: "(string|element)",
      display: "string",
      offset: "(array|string|function)",
      popperConfig: "(null|object|function)",
      reference: "(string|element|object)",
    };
  class rn extends B {
    constructor(e, t) {
      super(e, t),
        (this._popper = null),
        (this._parent = this._element.parentNode),
        (this._menu =
          z.next(this._element, Xt)[0] ||
          z.prev(this._element, Xt)[0] ||
          z.findOne(Xt, this._parent)),
        (this._inNavbar = this._detectNavbar());
    }
    static get Default() {
      return tn;
    }
    static get DefaultType() {
      return nn;
    }
    static get NAME() {
      return Vt;
    }
    toggle() {
      return this._isShown() ? this.hide() : this.show();
    }
    show() {
      if (l(this._element) || this._isShown()) return;
      const e = { relatedTarget: this._element };
      if (!j.trigger(this._element, "show.bs.dropdown", e).defaultPrevented) {
        if (
          (this._createPopper(),
          "ontouchstart" in document.documentElement &&
            !this._parent.closest(".navbar-nav"))
        )
          for (const e of [].concat(...document.body.children))
            j.on(e, "mouseover", u);
        this._element.focus(),
          this._element.setAttribute("aria-expanded", !0),
          this._menu.classList.add(Ut),
          this._element.classList.add(Ut),
          j.trigger(this._element, "shown.bs.dropdown", e);
      }
    }
    hide() {
      if (l(this._element) || !this._isShown()) return;
      const e = { relatedTarget: this._element };
      this._completeHide(e);
    }
    dispose() {
      this._popper && this._popper.destroy(), super.dispose();
    }
    update() {
      (this._inNavbar = this._detectNavbar()),
        this._popper && this._popper.update();
    }
    _completeHide(e) {
      if (!j.trigger(this._element, "hide.bs.dropdown", e).defaultPrevented) {
        if ("ontouchstart" in document.documentElement)
          for (const e of [].concat(...document.body.children))
            j.off(e, "mouseover", u);
        this._popper && this._popper.destroy(),
          this._menu.classList.remove(Ut),
          this._element.classList.remove(Ut),
          this._element.setAttribute("aria-expanded", "false"),
          $.removeDataAttribute(this._menu, "popper"),
          j.trigger(this._element, "hidden.bs.dropdown", e);
      }
    }
    _getConfig(e) {
      if (
        "object" == typeof (e = super._getConfig(e)).reference &&
        !s(e.reference) &&
        "function" != typeof e.reference.getBoundingClientRect
      )
        throw new TypeError(
          Vt.toUpperCase() +
            ': Option "reference" provided type "object" without a required "getBoundingClientRect" method.'
        );
      return e;
    }
    _createPopper() {
      if (void 0 === Bt)
        throw new TypeError(
          "Bootstrap's dropdowns require Popper (https://popper.js.org)"
        );
      let e = this._element;
      "parent" === this._config.reference
        ? (e = this._parent)
        : s(this._config.reference)
        ? (e = o(this._config.reference))
        : "object" == typeof this._config.reference &&
          (e = this._config.reference);
      const t = this._getPopperConfig();
      this._popper = Ht(e, this._menu, t);
    }
    _isShown() {
      return this._menu.classList.contains(Ut);
    }
    _getPlacement() {
      const e = this._parent;
      if (e.classList.contains("dropend")) return Gt;
      if (e.classList.contains("dropstart")) return en;
      if (e.classList.contains("dropup-center")) return "top";
      if (e.classList.contains("dropdown-center")) return "bottom";
      const t =
        "end" ===
        getComputedStyle(this._menu).getPropertyValue("--bs-position").trim();
      return e.classList.contains("dropup") ? (t ? Qt : Kt) : t ? Jt : Zt;
    }
    _detectNavbar() {
      return null !== this._element.closest(".navbar");
    }
    _getOffset() {
      const { offset: e } = this._config;
      return "string" == typeof e
        ? e.split(",").map((e) => Number.parseInt(e, 10))
        : "function" == typeof e
        ? (t) => e(t, this._element)
        : e;
    }
    _getPopperConfig() {
      const e = {
        placement: this._getPlacement(),
        modifiers: [
          {
            name: "preventOverflow",
            options: { boundary: this._config.boundary },
          },
          { name: "offset", options: { offset: this._getOffset() } },
        ],
      };
      return (
        (this._inNavbar || "static" === this._config.display) &&
          ($.setDataAttribute(this._menu, "popper", "static"),
          (e.modifiers = [{ name: "applyStyles", enabled: !1 }])),
        { ...e, ...m(this._config.popperConfig, [e]) }
      );
    }
    _selectMenuItem({ key: e, target: t }) {
      const n = z
        .find(
          ".dropdown-menu .dropdown-item:not(.disabled):not(:disabled)",
          this._menu
        )
        .filter((e) => a(e));
      n.length && _(n, t, e === Rt, !n.includes(t)).focus();
    }
    static jQueryInterface(e) {
      return this.each(function () {
        const t = rn.getOrCreateInstance(this, e);
        if ("string" == typeof e) {
          if (void 0 === t[e]) throw new TypeError(`No method named "${e}"`);
          t[e]();
        }
      });
    }
    static clearMenus(e) {
      if (2 === e.button || ("keyup" === e.type && "Tab" !== e.key)) return;
      const t = z.find(
        '[data-bs-toggle="dropdown"]:not(.disabled):not(:disabled).show'
      );
      for (const n of t) {
        const t = rn.getInstance(n);
        if (!t || !1 === t._config.autoClose) continue;
        const i = e.composedPath(),
          r = i.includes(t._menu);
        if (
          i.includes(t._element) ||
          ("inside" === t._config.autoClose && !r) ||
          ("outside" === t._config.autoClose && r)
        )
          continue;
        if (
          t._menu.contains(e.target) &&
          (("keyup" === e.type && "Tab" === e.key) ||
            /input|select|option|textarea|form/i.test(e.target.tagName))
        )
          continue;
        const s = { relatedTarget: t._element };
        "click" === e.type && (s.clickEvent = e), t._completeHide(s);
      }
    }
    static dataApiKeydownHandler(e) {
      const t = /input|textarea/i.test(e.target.tagName),
        n = "Escape" === e.key,
        i = [zt, Rt].includes(e.key);
      if (!i && !n) return;
      if (t && !n) return;
      e.preventDefault();
      const r = this.matches(Yt)
          ? this
          : z.prev(this, Yt)[0] ||
            z.next(this, Yt)[0] ||
            z.findOne(Yt, e.delegateTarget.parentNode),
        s = rn.getOrCreateInstance(r);
      if (i) return e.stopPropagation(), s.show(), void s._selectMenuItem(e);
      s._isShown() && (e.stopPropagation(), s.hide(), r.focus());
    }
  }
  j.on(document, qt, Yt, rn.dataApiKeydownHandler),
    j.on(document, qt, Xt, rn.dataApiKeydownHandler),
    j.on(document, Wt, rn.clearMenus),
    j.on(document, "keyup.bs.dropdown.data-api", rn.clearMenus),
    j.on(document, Wt, Yt, function (e) {
      e.preventDefault(), rn.getOrCreateInstance(this).toggle();
    }),
    g(rn);
  const sn = "mousedown.bs.backdrop",
    on = {
      className: "modal-backdrop",
      clickCallback: null,
      isAnimated: !1,
      isVisible: !0,
      rootElement: "body",
    },
    an = {
      className: "string",
      clickCallback: "(function|null)",
      isAnimated: "boolean",
      isVisible: "boolean",
      rootElement: "(element|string)",
    };
  class ln extends H {
    constructor(e) {
      super(),
        (this._config = this._getConfig(e)),
        (this._isAppended = !1),
        (this._element = null);
    }
    static get Default() {
      return on;
    }
    static get DefaultType() {
      return an;
    }
    static get NAME() {
      return "backdrop";
    }
    show(e) {
      if (!this._config.isVisible) return void m(e);
      this._append();
      const t = this._getElement();
      this._config.isAnimated && d(t),
        t.classList.add("show"),
        this._emulateAnimation(() => {
          m(e);
        });
    }
    hide(e) {
      this._config.isVisible
        ? (this._getElement().classList.remove("show"),
          this._emulateAnimation(() => {
            this.dispose(), m(e);
          }))
        : m(e);
    }
    dispose() {
      this._isAppended &&
        (j.off(this._element, sn),
        this._element.remove(),
        (this._isAppended = !1));
    }
    _getElement() {
      if (!this._element) {
        const e = document.createElement("div");
        (e.className = this._config.className),
          this._config.isAnimated && e.classList.add("fade"),
          (this._element = e);
      }
      return this._element;
    }
    _configAfterMerge(e) {
      return (e.rootElement = o(e.rootElement)), e;
    }
    _append() {
      if (this._isAppended) return;
      const e = this._getElement();
      this._config.rootElement.append(e),
        j.on(e, sn, () => {
          m(this._config.clickCallback);
        }),
        (this._isAppended = !0);
    }
    _emulateAnimation(e) {
      b(e, this._getElement(), this._config.isAnimated);
    }
  }
  const cn = ".bs.focustrap",
    un = "backward",
    dn = { autofocus: !0, trapElement: null },
    hn = { autofocus: "boolean", trapElement: "element" };
  class fn extends H {
    constructor(e) {
      super(),
        (this._config = this._getConfig(e)),
        (this._isActive = !1),
        (this._lastTabNavDirection = null);
    }
    static get Default() {
      return dn;
    }
    static get DefaultType() {
      return hn;
    }
    static get NAME() {
      return "focustrap";
    }
    activate() {
      this._isActive ||
        (this._config.autofocus && this._config.trapElement.focus(),
        j.off(document, cn),
        j.on(document, "focusin.bs.focustrap", (e) => this._handleFocusin(e)),
        j.on(document, "keydown.tab.bs.focustrap", (e) =>
          this._handleKeydown(e)
        ),
        (this._isActive = !0));
    }
    deactivate() {
      this._isActive && ((this._isActive = !1), j.off(document, cn));
    }
    _handleFocusin(e) {
      const { trapElement: t } = this._config;
      if (e.target === document || e.target === t || t.contains(e.target))
        return;
      const n = z.focusableChildren(t);
      0 === n.length
        ? t.focus()
        : this._lastTabNavDirection === un
        ? n[n.length - 1].focus()
        : n[0].focus();
    }
    _handleKeydown(e) {
      "Tab" === e.key &&
        (this._lastTabNavDirection = e.shiftKey ? un : "forward");
    }
  }
  const pn = ".fixed-top, .fixed-bottom, .is-fixed, .sticky-top",
    gn = ".sticky-top",
    mn = "padding-right",
    bn = "margin-right";
  class _n {
    constructor() {
      this._element = document.body;
    }
    getWidth() {
      const e = document.documentElement.clientWidth;
      return Math.abs(window.innerWidth - e);
    }
    hide() {
      const e = this.getWidth();
      this._disableOverFlow(),
        this._setElementAttributes(this._element, mn, (t) => t + e),
        this._setElementAttributes(pn, mn, (t) => t + e),
        this._setElementAttributes(gn, bn, (t) => t - e);
    }
    reset() {
      this._resetElementAttributes(this._element, "overflow"),
        this._resetElementAttributes(this._element, mn),
        this._resetElementAttributes(pn, mn),
        this._resetElementAttributes(gn, bn);
    }
    isOverflowing() {
      return this.getWidth() > 0;
    }
    _disableOverFlow() {
      this._saveInitialAttribute(this._element, "overflow"),
        (this._element.style.overflow = "hidden");
    }
    _setElementAttributes(e, t, n) {
      const i = this.getWidth();
      this._applyManipulationCallback(e, (e) => {
        if (e !== this._element && window.innerWidth > e.clientWidth + i)
          return;
        this._saveInitialAttribute(e, t);
        const r = window.getComputedStyle(e).getPropertyValue(t);
        e.style.setProperty(t, n(Number.parseFloat(r)) + "px");
      });
    }
    _saveInitialAttribute(e, t) {
      const n = e.style.getPropertyValue(t);
      n && $.setDataAttribute(e, t, n);
    }
    _resetElementAttributes(e, t) {
      this._applyManipulationCallback(e, (e) => {
        const n = $.getDataAttribute(e, t);
        null !== n
          ? ($.removeDataAttribute(e, t), e.style.setProperty(t, n))
          : e.style.removeProperty(t);
      });
    }
    _applyManipulationCallback(e, t) {
      if (s(e)) t(e);
      else for (const n of z.find(e, this._element)) t(n);
    }
  }
  const yn = ".bs.modal",
    vn = "hidden.bs.modal",
    wn = "show.bs.modal",
    An = "modal-open",
    En = "modal-static",
    xn = { backdrop: !0, focus: !0, keyboard: !0 },
    kn = {
      backdrop: "(boolean|string)",
      focus: "boolean",
      keyboard: "boolean",
    };
  class Sn extends B {
    constructor(e, t) {
      super(e, t),
        (this._dialog = z.findOne(".modal-dialog", this._element)),
        (this._backdrop = this._initializeBackDrop()),
        (this._focustrap = this._initializeFocusTrap()),
        (this._isShown = !1),
        (this._isTransitioning = !1),
        (this._scrollBar = new _n()),
        this._addEventListeners();
    }
    static get Default() {
      return xn;
    }
    static get DefaultType() {
      return kn;
    }
    static get NAME() {
      return "modal";
    }
    toggle(e) {
      return this._isShown ? this.hide() : this.show(e);
    }
    show(e) {
      this._isShown ||
        this._isTransitioning ||
        j.trigger(this._element, wn, { relatedTarget: e }).defaultPrevented ||
        ((this._isShown = !0),
        (this._isTransitioning = !0),
        this._scrollBar.hide(),
        document.body.classList.add(An),
        this._adjustDialog(),
        this._backdrop.show(() => this._showElement(e)));
    }
    hide() {
      this._isShown &&
        !this._isTransitioning &&
        (j.trigger(this._element, "hide.bs.modal").defaultPrevented ||
          ((this._isShown = !1),
          (this._isTransitioning = !0),
          this._focustrap.deactivate(),
          this._element.classList.remove("show"),
          this._queueCallback(
            () => this._hideModal(),
            this._element,
            this._isAnimated()
          )));
    }
    dispose() {
      j.off(window, yn),
        j.off(this._dialog, yn),
        this._backdrop.dispose(),
        this._focustrap.deactivate(),
        super.dispose();
    }
    handleUpdate() {
      this._adjustDialog();
    }
    _initializeBackDrop() {
      return new ln({
        isVisible: Boolean(this._config.backdrop),
        isAnimated: this._isAnimated(),
      });
    }
    _initializeFocusTrap() {
      return new fn({ trapElement: this._element });
    }
    _showElement(e) {
      document.body.contains(this._element) ||
        document.body.append(this._element),
        (this._element.style.display = "block"),
        this._element.removeAttribute("aria-hidden"),
        this._element.setAttribute("aria-modal", !0),
        this._element.setAttribute("role", "dialog"),
        (this._element.scrollTop = 0);
      const t = z.findOne(".modal-body", this._dialog);
      t && (t.scrollTop = 0),
        d(this._element),
        this._element.classList.add("show"),
        this._queueCallback(
          () => {
            this._config.focus && this._focustrap.activate(),
              (this._isTransitioning = !1),
              j.trigger(this._element, "shown.bs.modal", { relatedTarget: e });
          },
          this._dialog,
          this._isAnimated()
        );
    }
    _addEventListeners() {
      j.on(this._element, "keydown.dismiss.bs.modal", (e) => {
        "Escape" === e.key &&
          (this._config.keyboard
            ? this.hide()
            : this._triggerBackdropTransition());
      }),
        j.on(window, "resize.bs.modal", () => {
          this._isShown && !this._isTransitioning && this._adjustDialog();
        }),
        j.on(this._element, "mousedown.dismiss.bs.modal", (e) => {
          j.one(this._element, "click.dismiss.bs.modal", (t) => {
            this._element === e.target &&
              this._element === t.target &&
              ("static" !== this._config.backdrop
                ? this._config.backdrop && this.hide()
                : this._triggerBackdropTransition());
          });
        });
    }
    _hideModal() {
      (this._element.style.display = "none"),
        this._element.setAttribute("aria-hidden", !0),
        this._element.removeAttribute("aria-modal"),
        this._element.removeAttribute("role"),
        (this._isTransitioning = !1),
        this._backdrop.hide(() => {
          document.body.classList.remove(An),
            this._resetAdjustments(),
            this._scrollBar.reset(),
            j.trigger(this._element, vn);
        });
    }
    _isAnimated() {
      return this._element.classList.contains("fade");
    }
    _triggerBackdropTransition() {
      if (j.trigger(this._element, "hidePrevented.bs.modal").defaultPrevented)
        return;
      const e =
          this._element.scrollHeight > document.documentElement.clientHeight,
        t = this._element.style.overflowY;
      "hidden" === t ||
        this._element.classList.contains(En) ||
        (e || (this._element.style.overflowY = "hidden"),
        this._element.classList.add(En),
        this._queueCallback(() => {
          this._element.classList.remove(En),
            this._queueCallback(() => {
              this._element.style.overflowY = t;
            }, this._dialog);
        }, this._dialog),
        this._element.focus());
    }
    _adjustDialog() {
      const e =
          this._element.scrollHeight > document.documentElement.clientHeight,
        t = this._scrollBar.getWidth(),
        n = t > 0;
      if (n && !e) {
        const e = p() ? "paddingLeft" : "paddingRight";
        this._element.style[e] = t + "px";
      }
      if (!n && e) {
        const e = p() ? "paddingRight" : "paddingLeft";
        this._element.style[e] = t + "px";
      }
    }
    _resetAdjustments() {
      (this._element.style.paddingLeft = ""),
        (this._element.style.paddingRight = "");
    }
    static jQueryInterface(e, t) {
      return this.each(function () {
        const n = Sn.getOrCreateInstance(this, e);
        if ("string" == typeof e) {
          if (void 0 === n[e]) throw new TypeError(`No method named "${e}"`);
          n[e](t);
        }
      });
    }
  }
  j.on(
    document,
    "click.bs.modal.data-api",
    '[data-bs-toggle="modal"]',
    function (e) {
      const t = z.getElementFromSelector(this);
      ["A", "AREA"].includes(this.tagName) && e.preventDefault(),
        j.one(t, wn, (e) => {
          e.defaultPrevented ||
            j.one(t, vn, () => {
              a(this) && this.focus();
            });
        });
      const n = z.findOne(".modal.show");
      n && Sn.getInstance(n).hide(), Sn.getOrCreateInstance(t).toggle(this);
    }
  ),
    R(Sn),
    g(Sn);
  const Tn = "showing",
    Pn = ".offcanvas.show",
    Cn = "hidePrevented.bs.offcanvas",
    On = "hidden.bs.offcanvas",
    Ln = { backdrop: !0, keyboard: !0, scroll: !1 },
    Fn = {
      backdrop: "(boolean|string)",
      keyboard: "boolean",
      scroll: "boolean",
    };
  class Dn extends B {
    constructor(e, t) {
      super(e, t),
        (this._isShown = !1),
        (this._backdrop = this._initializeBackDrop()),
        (this._focustrap = this._initializeFocusTrap()),
        this._addEventListeners();
    }
    static get Default() {
      return Ln;
    }
    static get DefaultType() {
      return Fn;
    }
    static get NAME() {
      return "offcanvas";
    }
    toggle(e) {
      return this._isShown ? this.hide() : this.show(e);
    }
    show(e) {
      this._isShown ||
        j.trigger(this._element, "show.bs.offcanvas", { relatedTarget: e })
          .defaultPrevented ||
        ((this._isShown = !0),
        this._backdrop.show(),
        this._config.scroll || new _n().hide(),
        this._element.setAttribute("aria-modal", !0),
        this._element.setAttribute("role", "dialog"),
        this._element.classList.add(Tn),
        this._queueCallback(
          () => {
            (this._config.scroll && !this._config.backdrop) ||
              this._focustrap.activate(),
              this._element.classList.add("show"),
              this._element.classList.remove(Tn),
              j.trigger(this._element, "shown.bs.offcanvas", {
                relatedTarget: e,
              });
          },
          this._element,
          !0
        ));
    }
    hide() {
      this._isShown &&
        (j.trigger(this._element, "hide.bs.offcanvas").defaultPrevented ||
          (this._focustrap.deactivate(),
          this._element.blur(),
          (this._isShown = !1),
          this._element.classList.add("hiding"),
          this._backdrop.hide(),
          this._queueCallback(
            () => {
              this._element.classList.remove("show", "hiding"),
                this._element.removeAttribute("aria-modal"),
                this._element.removeAttribute("role"),
                this._config.scroll || new _n().reset(),
                j.trigger(this._element, On);
            },
            this._element,
            !0
          )));
    }
    dispose() {
      this._backdrop.dispose(), this._focustrap.deactivate(), super.dispose();
    }
    _initializeBackDrop() {
      const e = Boolean(this._config.backdrop);
      return new ln({
        className: "offcanvas-backdrop",
        isVisible: e,
        isAnimated: !0,
        rootElement: this._element.parentNode,
        clickCallback: e
          ? () => {
              "static" !== this._config.backdrop
                ? this.hide()
                : j.trigger(this._element, Cn);
            }
          : null,
      });
    }
    _initializeFocusTrap() {
      return new fn({ trapElement: this._element });
    }
    _addEventListeners() {
      j.on(this._element, "keydown.dismiss.bs.offcanvas", (e) => {
        "Escape" === e.key &&
          (this._config.keyboard ? this.hide() : j.trigger(this._element, Cn));
      });
    }
    static jQueryInterface(e) {
      return this.each(function () {
        const t = Dn.getOrCreateInstance(this, e);
        if ("string" == typeof e) {
          if (void 0 === t[e] || e.startsWith("_") || "constructor" === e)
            throw new TypeError(`No method named "${e}"`);
          t[e](this);
        }
      });
    }
  }
  j.on(
    document,
    "click.bs.offcanvas.data-api",
    '[data-bs-toggle="offcanvas"]',
    function (e) {
      const t = z.getElementFromSelector(this);
      if ((["A", "AREA"].includes(this.tagName) && e.preventDefault(), l(this)))
        return;
      j.one(t, On, () => {
        a(this) && this.focus();
      });
      const n = z.findOne(Pn);
      n && n !== t && Dn.getInstance(n).hide(),
        Dn.getOrCreateInstance(t).toggle(this);
    }
  ),
    j.on(window, "load.bs.offcanvas.data-api", () => {
      for (const e of z.find(Pn)) Dn.getOrCreateInstance(e).show();
    }),
    j.on(window, "resize.bs.offcanvas", () => {
      for (const e of z.find("[aria-modal][class*=show][class*=offcanvas-]"))
        "fixed" !== getComputedStyle(e).position &&
          Dn.getOrCreateInstance(e).hide();
    }),
    R(Dn),
    g(Dn);
  const jn = {
      "*": ["class", "dir", "id", "lang", "role", /^aria-[\w-]*$/i],
      a: ["target", "href", "title", "rel"],
      area: [],
      b: [],
      br: [],
      col: [],
      code: [],
      div: [],
      em: [],
      hr: [],
      h1: [],
      h2: [],
      h3: [],
      h4: [],
      h5: [],
      h6: [],
      i: [],
      img: ["src", "srcset", "alt", "title", "width", "height"],
      li: [],
      ol: [],
      p: [],
      pre: [],
      s: [],
      small: [],
      span: [],
      sub: [],
      sup: [],
      strong: [],
      u: [],
      ul: [],
    },
    In = new Set([
      "background",
      "cite",
      "href",
      "itemtype",
      "longdesc",
      "poster",
      "src",
      "xlink:href",
    ]),
    Mn = /^(?!javascript:)(?:[a-z0-9+.-]+:|[^&:/?#]*(?:[/?#]|$))/i,
    Nn = (e, t) => {
      const n = e.nodeName.toLowerCase();
      return t.includes(n)
        ? !In.has(n) || Boolean(Mn.test(e.nodeValue))
        : t.filter((e) => e instanceof RegExp).some((e) => e.test(n));
    },
    $n = {
      allowList: jn,
      content: {},
      extraClass: "",
      html: !1,
      sanitize: !0,
      sanitizeFn: null,
      template: "<div></div>",
    },
    Hn = {
      allowList: "object",
      content: "object",
      extraClass: "(string|function)",
      html: "boolean",
      sanitize: "boolean",
      sanitizeFn: "(null|function)",
      template: "string",
    },
    Bn = {
      entry: "(string|element|function|null)",
      selector: "(string|element)",
    };
  class Vn extends H {
    constructor(e) {
      super(), (this._config = this._getConfig(e));
    }
    static get Default() {
      return $n;
    }
    static get DefaultType() {
      return Hn;
    }
    static get NAME() {
      return "TemplateFactory";
    }
    getContent() {
      return Object.values(this._config.content)
        .map((e) => this._resolvePossibleFunction(e))
        .filter(Boolean);
    }
    hasContent() {
      return this.getContent().length > 0;
    }
    changeContent(e) {
      return (
        this._checkContent(e),
        (this._config.content = { ...this._config.content, ...e }),
        this
      );
    }
    toHtml() {
      const e = document.createElement("div");
      e.innerHTML = this._maybeSanitize(this._config.template);
      for (const [t, n] of Object.entries(this._config.content))
        this._setContent(e, n, t);
      const t = e.children[0],
        n = this._resolvePossibleFunction(this._config.extraClass);
      return n && t.classList.add(...n.split(" ")), t;
    }
    _typeCheckConfig(e) {
      super._typeCheckConfig(e), this._checkContent(e.content);
    }
    _checkContent(e) {
      for (const [t, n] of Object.entries(e))
        super._typeCheckConfig({ selector: t, entry: n }, Bn);
    }
    _setContent(e, t, n) {
      const i = z.findOne(n, e);
      i &&
        ((t = this._resolvePossibleFunction(t))
          ? s(t)
            ? this._putElementInTemplate(o(t), i)
            : this._config.html
            ? (i.innerHTML = this._maybeSanitize(t))
            : (i.textContent = t)
          : i.remove());
    }
    _maybeSanitize(e) {
      return this._config.sanitize
        ? (function (e, t, n) {
            if (!e.length) return e;
            if (n && "function" == typeof n) return n(e);
            const i = new window.DOMParser().parseFromString(e, "text/html"),
              r = [].concat(...i.body.querySelectorAll("*"));
            for (const e of r) {
              const n = e.nodeName.toLowerCase();
              if (!Object.keys(t).includes(n)) {
                e.remove();
                continue;
              }
              const i = [].concat(...e.attributes),
                r = [].concat(t["*"] || [], t[n] || []);
              for (const t of i) Nn(t, r) || e.removeAttribute(t.nodeName);
            }
            return i.body.innerHTML;
          })(e, this._config.allowList, this._config.sanitizeFn)
        : e;
    }
    _resolvePossibleFunction(e) {
      return m(e, [this]);
    }
    _putElementInTemplate(e, t) {
      if (this._config.html) return (t.innerHTML = ""), void t.append(e);
      t.textContent = e.textContent;
    }
  }
  const zn = new Set(["sanitize", "allowList", "sanitizeFn"]),
    Rn = "fade",
    Wn = "show",
    qn = "hide.bs.modal",
    Un = "hover",
    Yn = {
      AUTO: "auto",
      TOP: "top",
      RIGHT: p() ? "left" : "right",
      BOTTOM: "bottom",
      LEFT: p() ? "right" : "left",
    },
    Xn = {
      allowList: jn,
      animation: !0,
      boundary: "clippingParents",
      container: !1,
      customClass: "",
      delay: 0,
      fallbackPlacements: ["top", "right", "bottom", "left"],
      html: !1,
      offset: [0, 6],
      placement: "top",
      popperConfig: null,
      sanitize: !0,
      sanitizeFn: null,
      selector: !1,
      template:
        '<div class="tooltip" role="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>',
      title: "",
      trigger: "hover focus",
    },
    Kn = {
      allowList: "object",
      animation: "boolean",
      boundary: "(string|element)",
      container: "(string|element|boolean)",
      customClass: "(string|function)",
      delay: "(number|object)",
      fallbackPlacements: "array",
      html: "boolean",
      offset: "(array|string|function)",
      placement: "(string|function)",
      popperConfig: "(null|object|function)",
      sanitize: "boolean",
      sanitizeFn: "(null|function)",
      selector: "(string|boolean)",
      template: "string",
      title: "(string|element|function)",
      trigger: "string",
    };
  class Qn extends B {
    constructor(e, t) {
      if (void 0 === Bt)
        throw new TypeError(
          "Bootstrap's tooltips require Popper (https://popper.js.org)"
        );
      super(e, t),
        (this._isEnabled = !0),
        (this._timeout = 0),
        (this._isHovered = null),
        (this._activeTrigger = {}),
        (this._popper = null),
        (this._templateFactory = null),
        (this._newContent = null),
        (this.tip = null),
        this._setListeners(),
        this._config.selector || this._fixTitle();
    }
    static get Default() {
      return Xn;
    }
    static get DefaultType() {
      return Kn;
    }
    static get NAME() {
      return "tooltip";
    }
    enable() {
      this._isEnabled = !0;
    }
    disable() {
      this._isEnabled = !1;
    }
    toggleEnabled() {
      this._isEnabled = !this._isEnabled;
    }
    toggle() {
      this._isEnabled &&
        ((this._activeTrigger.click = !this._activeTrigger.click),
        this._isShown() ? this._leave() : this._enter());
    }
    dispose() {
      clearTimeout(this._timeout),
        j.off(this._element.closest(".modal"), qn, this._hideModalHandler),
        this._element.getAttribute("data-bs-original-title") &&
          this._element.setAttribute(
            "title",
            this._element.getAttribute("data-bs-original-title")
          ),
        this._disposePopper(),
        super.dispose();
    }
    show() {
      if ("none" === this._element.style.display)
        throw new Error("Please use show on visible elements");
      if (!this._isWithContent() || !this._isEnabled) return;
      const e = j.trigger(this._element, this.constructor.eventName("show")),
        t = (
          c(this._element) || this._element.ownerDocument.documentElement
        ).contains(this._element);
      if (e.defaultPrevented || !t) return;
      this._disposePopper();
      const n = this._getTipElement();
      this._element.setAttribute("aria-describedby", n.getAttribute("id"));
      const { container: i } = this._config;
      if (
        (this._element.ownerDocument.documentElement.contains(this.tip) ||
          (i.append(n),
          j.trigger(this._element, this.constructor.eventName("inserted"))),
        (this._popper = this._createPopper(n)),
        n.classList.add(Wn),
        "ontouchstart" in document.documentElement)
      )
        for (const e of [].concat(...document.body.children))
          j.on(e, "mouseover", u);
      this._queueCallback(
        () => {
          j.trigger(this._element, this.constructor.eventName("shown")),
            !1 === this._isHovered && this._leave(),
            (this._isHovered = !1);
        },
        this.tip,
        this._isAnimated()
      );
    }
    hide() {
      if (
        this._isShown() &&
        !j.trigger(this._element, this.constructor.eventName("hide"))
          .defaultPrevented
      ) {
        if (
          (this._getTipElement().classList.remove(Wn),
          "ontouchstart" in document.documentElement)
        )
          for (const e of [].concat(...document.body.children))
            j.off(e, "mouseover", u);
        (this._activeTrigger.click = !1),
          (this._activeTrigger.focus = !1),
          (this._activeTrigger.hover = !1),
          (this._isHovered = null),
          this._queueCallback(
            () => {
              this._isWithActiveTrigger() ||
                (this._isHovered || this._disposePopper(),
                this._element.removeAttribute("aria-describedby"),
                j.trigger(this._element, this.constructor.eventName("hidden")));
            },
            this.tip,
            this._isAnimated()
          );
      }
    }
    update() {
      this._popper && this._popper.update();
    }
    _isWithContent() {
      return Boolean(this._getTitle());
    }
    _getTipElement() {
      return (
        this.tip ||
          (this.tip = this._createTipElement(
            this._newContent || this._getContentForTemplate()
          )),
        this.tip
      );
    }
    _createTipElement(e) {
      const t = this._getTemplateFactory(e).toHtml();
      if (!t) return null;
      t.classList.remove(Rn, Wn),
        t.classList.add(`bs-${this.constructor.NAME}-auto`);
      const n = ((e) => {
        do {
          e += Math.floor(1e6 * Math.random());
        } while (document.getElementById(e));
        return e;
      })(this.constructor.NAME).toString();
      return (
        t.setAttribute("id", n), this._isAnimated() && t.classList.add(Rn), t
      );
    }
    setContent(e) {
      (this._newContent = e),
        this._isShown() && (this._disposePopper(), this.show());
    }
    _getTemplateFactory(e) {
      return (
        this._templateFactory
          ? this._templateFactory.changeContent(e)
          : (this._templateFactory = new Vn({
              ...this._config,
              content: e,
              extraClass: this._resolvePossibleFunction(
                this._config.customClass
              ),
            })),
        this._templateFactory
      );
    }
    _getContentForTemplate() {
      return { ".tooltip-inner": this._getTitle() };
    }
    _getTitle() {
      return (
        this._resolvePossibleFunction(this._config.title) ||
        this._element.getAttribute("data-bs-original-title")
      );
    }
    _initializeOnDelegatedTarget(e) {
      return this.constructor.getOrCreateInstance(
        e.delegateTarget,
        this._getDelegateConfig()
      );
    }
    _isAnimated() {
      return (
        this._config.animation || (this.tip && this.tip.classList.contains(Rn))
      );
    }
    _isShown() {
      return this.tip && this.tip.classList.contains(Wn);
    }
    _createPopper(e) {
      const t = m(this._config.placement, [this, e, this._element]),
        n = Yn[t.toUpperCase()];
      return Ht(this._element, e, this._getPopperConfig(n));
    }
    _getOffset() {
      const { offset: e } = this._config;
      return "string" == typeof e
        ? e.split(",").map((e) => Number.parseInt(e, 10))
        : "function" == typeof e
        ? (t) => e(t, this._element)
        : e;
    }
    _resolvePossibleFunction(e) {
      return m(e, [this._element]);
    }
    _getPopperConfig(e) {
      const t = {
        placement: e,
        modifiers: [
          {
            name: "flip",
            options: { fallbackPlacements: this._config.fallbackPlacements },
          },
          { name: "offset", options: { offset: this._getOffset() } },
          {
            name: "preventOverflow",
            options: { boundary: this._config.boundary },
          },
          {
            name: "arrow",
            options: { element: `.${this.constructor.NAME}-arrow` },
          },
          {
            name: "preSetPlacement",
            enabled: !0,
            phase: "beforeMain",
            fn: (e) => {
              this._getTipElement().setAttribute(
                "data-popper-placement",
                e.state.placement
              );
            },
          },
        ],
      };
      return { ...t, ...m(this._config.popperConfig, [t]) };
    }
    _setListeners() {
      const e = this._config.trigger.split(" ");
      for (const t of e)
        if ("click" === t)
          j.on(
            this._element,
            this.constructor.eventName("click"),
            this._config.selector,
            (e) => {
              this._initializeOnDelegatedTarget(e).toggle();
            }
          );
        else if ("manual" !== t) {
          const e =
              t === Un
                ? this.constructor.eventName("mouseenter")
                : this.constructor.eventName("focusin"),
            n =
              t === Un
                ? this.constructor.eventName("mouseleave")
                : this.constructor.eventName("focusout");
          j.on(this._element, e, this._config.selector, (e) => {
            const t = this._initializeOnDelegatedTarget(e);
            (t._activeTrigger["focusin" === e.type ? "focus" : Un] = !0),
              t._enter();
          }),
            j.on(this._element, n, this._config.selector, (e) => {
              const t = this._initializeOnDelegatedTarget(e);
              (t._activeTrigger["focusout" === e.type ? "focus" : Un] =
                t._element.contains(e.relatedTarget)),
                t._leave();
            });
        }
      (this._hideModalHandler = () => {
        this._element && this.hide();
      }),
        j.on(this._element.closest(".modal"), qn, this._hideModalHandler);
    }
    _fixTitle() {
      const e = this._element.getAttribute("title");
      e &&
        (this._element.getAttribute("aria-label") ||
          this._element.textContent.trim() ||
          this._element.setAttribute("aria-label", e),
        this._element.setAttribute("data-bs-original-title", e),
        this._element.removeAttribute("title"));
    }
    _enter() {
      this._isShown() || this._isHovered
        ? (this._isHovered = !0)
        : ((this._isHovered = !0),
          this._setTimeout(() => {
            this._isHovered && this.show();
          }, this._config.delay.show));
    }
    _leave() {
      this._isWithActiveTrigger() ||
        ((this._isHovered = !1),
        this._setTimeout(() => {
          this._isHovered || this.hide();
        }, this._config.delay.hide));
    }
    _setTimeout(e, t) {
      clearTimeout(this._timeout), (this._timeout = setTimeout(e, t));
    }
    _isWithActiveTrigger() {
      return Object.values(this._activeTrigger).includes(!0);
    }
    _getConfig(e) {
      const t = $.getDataAttributes(this._element);
      for (const e of Object.keys(t)) zn.has(e) && delete t[e];
      return (
        (e = { ...t, ...("object" == typeof e && e ? e : {}) }),
        (e = this._mergeConfigObj(e)),
        (e = this._configAfterMerge(e)),
        this._typeCheckConfig(e),
        e
      );
    }
    _configAfterMerge(e) {
      return (
        (e.container = !1 === e.container ? document.body : o(e.container)),
        "number" == typeof e.delay &&
          (e.delay = { show: e.delay, hide: e.delay }),
        "number" == typeof e.title && (e.title = e.title.toString()),
        "number" == typeof e.content && (e.content = e.content.toString()),
        e
      );
    }
    _getDelegateConfig() {
      const e = {};
      for (const [t, n] of Object.entries(this._config))
        this.constructor.Default[t] !== n && (e[t] = n);
      return (e.selector = !1), (e.trigger = "manual"), e;
    }
    _disposePopper() {
      this._popper && (this._popper.destroy(), (this._popper = null)),
        this.tip && (this.tip.remove(), (this.tip = null));
    }
    static jQueryInterface(e) {
      return this.each(function () {
        const t = Qn.getOrCreateInstance(this, e);
        if ("string" == typeof e) {
          if (void 0 === t[e]) throw new TypeError(`No method named "${e}"`);
          t[e]();
        }
      });
    }
  }
  g(Qn);
  const Zn = {
      ...Qn.Default,
      content: "",
      offset: [0, 8],
      placement: "right",
      template:
        '<div class="popover" role="tooltip"><div class="popover-arrow"></div><h3 class="popover-header"></h3><div class="popover-body"></div></div>',
      trigger: "click",
    },
    Jn = { ...Qn.DefaultType, content: "(null|string|element|function)" };
  class Gn extends Qn {
    static get Default() {
      return Zn;
    }
    static get DefaultType() {
      return Jn;
    }
    static get NAME() {
      return "popover";
    }
    _isWithContent() {
      return this._getTitle() || this._getContent();
    }
    _getContentForTemplate() {
      return {
        ".popover-header": this._getTitle(),
        ".popover-body": this._getContent(),
      };
    }
    _getContent() {
      return this._resolvePossibleFunction(this._config.content);
    }
    static jQueryInterface(e) {
      return this.each(function () {
        const t = Gn.getOrCreateInstance(this, e);
        if ("string" == typeof e) {
          if (void 0 === t[e]) throw new TypeError(`No method named "${e}"`);
          t[e]();
        }
      });
    }
  }
  g(Gn);
  const ei = "click.bs.scrollspy",
    ti = "active",
    ni = {
      offset: null,
      rootMargin: "0px 0px -25%",
      smoothScroll: !1,
      target: null,
      threshold: [0.1, 0.5, 1],
    },
    ii = {
      offset: "(number|null)",
      rootMargin: "string",
      smoothScroll: "boolean",
      target: "element",
      threshold: "array",
    };
  class ri extends B {
    constructor(e, t) {
      super(e, t),
        (this._targetLinks = new Map()),
        (this._observableSections = new Map()),
        (this._rootElement =
          "visible" === getComputedStyle(this._element).overflowY
            ? null
            : this._element),
        (this._activeTarget = null),
        (this._observer = null),
        (this._previousScrollData = { visibleEntryTop: 0, parentScrollTop: 0 }),
        this.refresh();
    }
    static get Default() {
      return ni;
    }
    static get DefaultType() {
      return ii;
    }
    static get NAME() {
      return "scrollspy";
    }
    refresh() {
      this._initializeTargetsAndObservables(),
        this._maybeEnableSmoothScroll(),
        this._observer
          ? this._observer.disconnect()
          : (this._observer = this._getNewObserver());
      for (const e of this._observableSections.values())
        this._observer.observe(e);
    }
    dispose() {
      this._observer.disconnect(), super.dispose();
    }
    _configAfterMerge(e) {
      return (
        (e.target = o(e.target) || document.body),
        (e.rootMargin = e.offset ? e.offset + "px 0px -30%" : e.rootMargin),
        "string" == typeof e.threshold &&
          (e.threshold = e.threshold
            .split(",")
            .map((e) => Number.parseFloat(e))),
        e
      );
    }
    _maybeEnableSmoothScroll() {
      this._config.smoothScroll &&
        (j.off(this._config.target, ei),
        j.on(this._config.target, ei, "[href]", (e) => {
          const t = this._observableSections.get(e.target.hash);
          if (t) {
            e.preventDefault();
            const n = this._rootElement || window,
              i = t.offsetTop - this._element.offsetTop;
            if (n.scrollTo)
              return void n.scrollTo({ top: i, behavior: "smooth" });
            n.scrollTop = i;
          }
        }));
    }
    _getNewObserver() {
      const e = {
        root: this._rootElement,
        threshold: this._config.threshold,
        rootMargin: this._config.rootMargin,
      };
      return new IntersectionObserver((e) => this._observerCallback(e), e);
    }
    _observerCallback(e) {
      const t = (e) => this._targetLinks.get("#" + e.target.id),
        n = (e) => {
          (this._previousScrollData.visibleEntryTop = e.target.offsetTop),
            this._process(t(e));
        },
        i = (this._rootElement || document.documentElement).scrollTop,
        r = i >= this._previousScrollData.parentScrollTop;
      this._previousScrollData.parentScrollTop = i;
      for (const s of e) {
        if (!s.isIntersecting) {
          (this._activeTarget = null), this._clearActiveClass(t(s));
          continue;
        }
        const e =
          s.target.offsetTop >= this._previousScrollData.visibleEntryTop;
        if (r && e) {
          if ((n(s), !i)) return;
        } else r || e || n(s);
      }
    }
    _initializeTargetsAndObservables() {
      (this._targetLinks = new Map()), (this._observableSections = new Map());
      const e = z.find("[href]", this._config.target);
      for (const t of e) {
        if (!t.hash || l(t)) continue;
        const e = z.findOne(decodeURI(t.hash), this._element);
        a(e) &&
          (this._targetLinks.set(decodeURI(t.hash), t),
          this._observableSections.set(t.hash, e));
      }
    }
    _process(e) {
      this._activeTarget !== e &&
        (this._clearActiveClass(this._config.target),
        (this._activeTarget = e),
        e.classList.add(ti),
        this._activateParents(e),
        j.trigger(this._element, "activate.bs.scrollspy", {
          relatedTarget: e,
        }));
    }
    _activateParents(e) {
      if (e.classList.contains("dropdown-item"))
        z.findOne(".dropdown-toggle", e.closest(".dropdown")).classList.add(ti);
      else
        for (const t of z.parents(e, ".nav, .list-group"))
          for (const e of z.prev(
            t,
            ".nav-link, .nav-item > .nav-link, .list-group-item"
          ))
            e.classList.add(ti);
    }
    _clearActiveClass(e) {
      e.classList.remove(ti);
      const t = z.find("[href].active", e);
      for (const e of t) e.classList.remove(ti);
    }
    static jQueryInterface(e) {
      return this.each(function () {
        const t = ri.getOrCreateInstance(this, e);
        if ("string" == typeof e) {
          if (void 0 === t[e] || e.startsWith("_") || "constructor" === e)
            throw new TypeError(`No method named "${e}"`);
          t[e]();
        }
      });
    }
  }
  j.on(window, "load.bs.scrollspy.data-api", () => {
    for (const e of z.find('[data-bs-spy="scroll"]')) ri.getOrCreateInstance(e);
  }),
    g(ri);
  const si = "ArrowLeft",
    oi = "ArrowRight",
    ai = "ArrowUp",
    li = "ArrowDown",
    ci = "active",
    ui = "show",
    di =
      '[data-bs-toggle="tab"], [data-bs-toggle="pill"], [data-bs-toggle="list"]',
    hi =
      '.nav-link:not(.dropdown-toggle), .list-group-item:not(.dropdown-toggle), [role="tab"]:not(.dropdown-toggle), ' +
      di;
  class fi extends B {
    constructor(e) {
      super(e),
        (this._parent = this._element.closest(
          '.list-group, .nav, [role="tablist"]'
        )),
        this._parent &&
          (this._setInitialAttributes(this._parent, this._getChildren()),
          j.on(this._element, "keydown.bs.tab", (e) => this._keydown(e)));
    }
    static get NAME() {
      return "tab";
    }
    show() {
      const e = this._element;
      if (this._elemIsActive(e)) return;
      const t = this._getActiveElem(),
        n = t ? j.trigger(t, "hide.bs.tab", { relatedTarget: e }) : null;
      j.trigger(e, "show.bs.tab", { relatedTarget: t }).defaultPrevented ||
        (n && n.defaultPrevented) ||
        (this._deactivate(t, e), this._activate(e, t));
    }
    _activate(e, t) {
      e &&
        (e.classList.add(ci),
        this._activate(z.getElementFromSelector(e)),
        this._queueCallback(
          () => {
            "tab" === e.getAttribute("role")
              ? (e.removeAttribute("tabindex"),
                e.setAttribute("aria-selected", !0),
                this._toggleDropDown(e, !0),
                j.trigger(e, "shown.bs.tab", { relatedTarget: t }))
              : e.classList.add(ui);
          },
          e,
          e.classList.contains("fade")
        ));
    }
    _deactivate(e, t) {
      e &&
        (e.classList.remove(ci),
        e.blur(),
        this._deactivate(z.getElementFromSelector(e)),
        this._queueCallback(
          () => {
            "tab" === e.getAttribute("role")
              ? (e.setAttribute("aria-selected", !1),
                e.setAttribute("tabindex", "-1"),
                this._toggleDropDown(e, !1),
                j.trigger(e, "hidden.bs.tab", { relatedTarget: t }))
              : e.classList.remove(ui);
          },
          e,
          e.classList.contains("fade")
        ));
    }
    _keydown(e) {
      if (![si, oi, ai, li].includes(e.key)) return;
      e.stopPropagation(), e.preventDefault();
      const t = [oi, li].includes(e.key),
        n = _(
          this._getChildren().filter((e) => !l(e)),
          e.target,
          t,
          !0
        );
      n && (n.focus({ preventScroll: !0 }), fi.getOrCreateInstance(n).show());
    }
    _getChildren() {
      return z.find(hi, this._parent);
    }
    _getActiveElem() {
      return this._getChildren().find((e) => this._elemIsActive(e)) || null;
    }
    _setInitialAttributes(e, t) {
      this._setAttributeIfNotExists(e, "role", "tablist");
      for (const e of t) this._setInitialAttributesOnChild(e);
    }
    _setInitialAttributesOnChild(e) {
      e = this._getInnerElement(e);
      const t = this._elemIsActive(e),
        n = this._getOuterElement(e);
      e.setAttribute("aria-selected", t),
        n !== e && this._setAttributeIfNotExists(n, "role", "presentation"),
        t || e.setAttribute("tabindex", "-1"),
        this._setAttributeIfNotExists(e, "role", "tab"),
        this._setInitialAttributesOnTargetPanel(e);
    }
    _setInitialAttributesOnTargetPanel(e) {
      const t = z.getElementFromSelector(e);
      t &&
        (this._setAttributeIfNotExists(t, "role", "tabpanel"),
        e.id && this._setAttributeIfNotExists(t, "aria-labelledby", "" + e.id));
    }
    _toggleDropDown(e, t) {
      const n = this._getOuterElement(e);
      if (!n.classList.contains("dropdown")) return;
      const i = (e, i) => {
        const r = z.findOne(e, n);
        r && r.classList.toggle(i, t);
      };
      i(".dropdown-toggle", ci),
        i(".dropdown-menu", ui),
        n.setAttribute("aria-expanded", t);
    }
    _setAttributeIfNotExists(e, t, n) {
      e.hasAttribute(t) || e.setAttribute(t, n);
    }
    _elemIsActive(e) {
      return e.classList.contains(ci);
    }
    _getInnerElement(e) {
      return e.matches(hi) ? e : z.findOne(hi, e);
    }
    _getOuterElement(e) {
      return e.closest(".nav-item, .list-group-item") || e;
    }
    static jQueryInterface(e) {
      return this.each(function () {
        const t = fi.getOrCreateInstance(this);
        if ("string" == typeof e) {
          if (void 0 === t[e] || e.startsWith("_") || "constructor" === e)
            throw new TypeError(`No method named "${e}"`);
          t[e]();
        }
      });
    }
  }
  j.on(document, "click.bs.tab", di, function (e) {
    ["A", "AREA"].includes(this.tagName) && e.preventDefault(),
      l(this) || fi.getOrCreateInstance(this).show();
  }),
    j.on(window, "load.bs.tab", () => {
      for (const e of z.find(
        '.active[data-bs-toggle="tab"], .active[data-bs-toggle="pill"], .active[data-bs-toggle="list"]'
      ))
        fi.getOrCreateInstance(e);
    }),
    g(fi);
  const pi = "show",
    gi = "showing",
    mi = { animation: "boolean", autohide: "boolean", delay: "number" },
    bi = { animation: !0, autohide: !0, delay: 5e3 };
  class _i extends B {
    constructor(e, t) {
      super(e, t),
        (this._timeout = null),
        (this._hasMouseInteraction = !1),
        (this._hasKeyboardInteraction = !1),
        this._setListeners();
    }
    static get Default() {
      return bi;
    }
    static get DefaultType() {
      return mi;
    }
    static get NAME() {
      return "toast";
    }
    show() {
      j.trigger(this._element, "show.bs.toast").defaultPrevented ||
        (this._clearTimeout(),
        this._config.animation && this._element.classList.add("fade"),
        this._element.classList.remove("hide"),
        d(this._element),
        this._element.classList.add(pi, gi),
        this._queueCallback(
          () => {
            this._element.classList.remove(gi),
              j.trigger(this._element, "shown.bs.toast"),
              this._maybeScheduleHide();
          },
          this._element,
          this._config.animation
        ));
    }
    hide() {
      this.isShown() &&
        (j.trigger(this._element, "hide.bs.toast").defaultPrevented ||
          (this._element.classList.add(gi),
          this._queueCallback(
            () => {
              this._element.classList.add("hide"),
                this._element.classList.remove(gi, pi),
                j.trigger(this._element, "hidden.bs.toast");
            },
            this._element,
            this._config.animation
          )));
    }
    dispose() {
      this._clearTimeout(),
        this.isShown() && this._element.classList.remove(pi),
        super.dispose();
    }
    isShown() {
      return this._element.classList.contains(pi);
    }
    _maybeScheduleHide() {
      this._config.autohide &&
        (this._hasMouseInteraction ||
          this._hasKeyboardInteraction ||
          (this._timeout = setTimeout(() => {
            this.hide();
          }, this._config.delay)));
    }
    _onInteraction(e, t) {
      switch (e.type) {
        case "mouseover":
        case "mouseout":
          this._hasMouseInteraction = t;
          break;
        case "focusin":
        case "focusout":
          this._hasKeyboardInteraction = t;
      }
      if (t) return void this._clearTimeout();
      const n = e.relatedTarget;
      this._element === n ||
        this._element.contains(n) ||
        this._maybeScheduleHide();
    }
    _setListeners() {
      j.on(this._element, "mouseover.bs.toast", (e) =>
        this._onInteraction(e, !0)
      ),
        j.on(this._element, "mouseout.bs.toast", (e) =>
          this._onInteraction(e, !1)
        ),
        j.on(this._element, "focusin.bs.toast", (e) =>
          this._onInteraction(e, !0)
        ),
        j.on(this._element, "focusout.bs.toast", (e) =>
          this._onInteraction(e, !1)
        );
    }
    _clearTimeout() {
      clearTimeout(this._timeout), (this._timeout = null);
    }
    static jQueryInterface(e) {
      return this.each(function () {
        const t = _i.getOrCreateInstance(this, e);
        if ("string" == typeof e) {
          if (void 0 === t[e]) throw new TypeError(`No method named "${e}"`);
          t[e](this);
        }
      });
    }
  }
  return (
    R(_i),
    g(_i),
    {
      Alert: W,
      Button: U,
      Carousel: oe,
      Collapse: fe,
      Dropdown: rn,
      Modal: Sn,
      Offcanvas: Dn,
      Popover: Gn,
      ScrollSpy: ri,
      Tab: fi,
      Toast: _i,
      Tooltip: Qn,
    }
  );
});
var _self =
    "undefined" != typeof window
      ? window
      : "undefined" != typeof WorkerGlobalScope &&
        self instanceof WorkerGlobalScope
      ? self
      : {},
  Prism = (function (e) {
    var t = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i,
      n = 0,
      i = {},
      r = {
        manual: e.Prism && e.Prism.manual,
        disableWorkerMessageHandler:
          e.Prism && e.Prism.disableWorkerMessageHandler,
        util: {
          encode: function e(t) {
            return t instanceof s
              ? new s(t.type, e(t.content), t.alias)
              : Array.isArray(t)
              ? t.map(e)
              : t
                  .replace(/&/g, "&amp;")
                  .replace(/</g, "&lt;")
                  .replace(/\u00a0/g, " ");
          },
          type: function (e) {
            return Object.prototype.toString.call(e).slice(8, -1);
          },
          objId: function (e) {
            return (
              e.__id || Object.defineProperty(e, "__id", { value: ++n }), e.__id
            );
          },
          clone: function e(t, n) {
            var i, s;
            switch (((n = n || {}), r.util.type(t))) {
              case "Object":
                if (((s = r.util.objId(t)), n[s])) return n[s];
                for (var o in ((i = {}), (n[s] = i), t))
                  t.hasOwnProperty(o) && (i[o] = e(t[o], n));
                return i;
              case "Array":
                return (
                  (s = r.util.objId(t)),
                  n[s]
                    ? n[s]
                    : ((i = []),
                      (n[s] = i),
                      t.forEach(function (t, r) {
                        i[r] = e(t, n);
                      }),
                      i)
                );
              default:
                return t;
            }
          },
          getLanguage: function (e) {
            for (; e; ) {
              var n = t.exec(e.className);
              if (n) return n[1].toLowerCase();
              e = e.parentElement;
            }
            return "none";
          },
          setLanguage: function (e, n) {
            (e.className = e.className.replace(RegExp(t, "gi"), "")),
              e.classList.add("language-" + n);
          },
          currentScript: function () {
            if ("undefined" == typeof document) return null;
            if ("currentScript" in document) return document.currentScript;
            try {
              throw new Error();
            } catch (i) {
              var e = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(i.stack) ||
                [])[1];
              if (e) {
                var t = document.getElementsByTagName("script");
                for (var n in t) if (t[n].src == e) return t[n];
              }
              return null;
            }
          },
          isActive: function (e, t, n) {
            for (var i = "no-" + t; e; ) {
              var r = e.classList;
              if (r.contains(t)) return !0;
              if (r.contains(i)) return !1;
              e = e.parentElement;
            }
            return !!n;
          },
        },
        languages: {
          plain: i,
          plaintext: i,
          text: i,
          txt: i,
          extend: function (e, t) {
            var n = r.util.clone(r.languages[e]);
            for (var i in t) n[i] = t[i];
            return n;
          },
          insertBefore: function (e, t, n, i) {
            var s = (i = i || r.languages)[e],
              o = {};
            for (var a in s)
              if (s.hasOwnProperty(a)) {
                if (a == t)
                  for (var l in n) n.hasOwnProperty(l) && (o[l] = n[l]);
                n.hasOwnProperty(a) || (o[a] = s[a]);
              }
            var c = i[e];
            return (
              (i[e] = o),
              r.languages.DFS(r.languages, function (t, n) {
                n === c && t != e && (this[t] = o);
              }),
              o
            );
          },
          DFS: function e(t, n, i, s) {
            s = s || {};
            var o = r.util.objId;
            for (var a in t)
              if (t.hasOwnProperty(a)) {
                n.call(t, a, t[a], i || a);
                var l = t[a],
                  c = r.util.type(l);
                "Object" !== c || s[o(l)]
                  ? "Array" !== c || s[o(l)] || ((s[o(l)] = !0), e(l, n, a, s))
                  : ((s[o(l)] = !0), e(l, n, null, s));
              }
          },
        },
        plugins: {},
        highlightAll: function (e, t) {
          r.highlightAllUnder(document, e, t);
        },
        highlightAllUnder: function (e, t, n) {
          var i = {
            callback: n,
            container: e,
            selector:
              'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code',
          };
          r.hooks.run("before-highlightall", i),
            (i.elements = Array.prototype.slice.apply(
              i.container.querySelectorAll(i.selector)
            )),
            r.hooks.run("before-all-elements-highlight", i);
          for (var s, o = 0; (s = i.elements[o++]); )
            r.highlightElement(s, !0 === t, i.callback);
        },
        highlightElement: function (t, n, i) {
          var s = r.util.getLanguage(t),
            o = r.languages[s];
          r.util.setLanguage(t, s);
          var a = t.parentElement;
          a && "pre" === a.nodeName.toLowerCase() && r.util.setLanguage(a, s);
          var l = { element: t, language: s, grammar: o, code: t.textContent };
          function c(e) {
            (l.highlightedCode = e),
              r.hooks.run("before-insert", l),
              (l.element.innerHTML = l.highlightedCode),
              r.hooks.run("after-highlight", l),
              r.hooks.run("complete", l),
              i && i.call(l.element);
          }
          if (
            (r.hooks.run("before-sanity-check", l),
            (a = l.element.parentElement) &&
              "pre" === a.nodeName.toLowerCase() &&
              !a.hasAttribute("tabindex") &&
              a.setAttribute("tabindex", "0"),
            !l.code)
          )
            return r.hooks.run("complete", l), void (i && i.call(l.element));
          if ((r.hooks.run("before-highlight", l), l.grammar))
            if (n && e.Worker) {
              var u = new Worker(r.filename);
              (u.onmessage = function (e) {
                c(e.data);
              }),
                u.postMessage(
                  JSON.stringify({
                    language: l.language,
                    code: l.code,
                    immediateClose: !0,
                  })
                );
            } else c(r.highlight(l.code, l.grammar, l.language));
          else c(r.util.encode(l.code));
        },
        highlight: function (e, t, n) {
          var i = { code: e, grammar: t, language: n };
          if ((r.hooks.run("before-tokenize", i), !i.grammar))
            throw new Error(
              'The language "' + i.language + '" has no grammar.'
            );
          return (
            (i.tokens = r.tokenize(i.code, i.grammar)),
            r.hooks.run("after-tokenize", i),
            s.stringify(r.util.encode(i.tokens), i.language)
          );
        },
        tokenize: function (e, t) {
          var n = t.rest;
          if (n) {
            for (var i in n) t[i] = n[i];
            delete t.rest;
          }
          var u = new a();
          return (
            l(u, u.head, e),
            (function e(t, n, i, a, u, d) {
              for (var h in i)
                if (i.hasOwnProperty(h) && i[h]) {
                  var f = i[h];
                  f = Array.isArray(f) ? f : [f];
                  for (var p = 0; p < f.length; ++p) {
                    if (d && d.cause == h + "," + p) return;
                    var g = f[p],
                      m = g.inside,
                      b = !!g.lookbehind,
                      _ = !!g.greedy,
                      y = g.alias;
                    if (_ && !g.pattern.global) {
                      var v = g.pattern.toString().match(/[imsuy]*$/)[0];
                      g.pattern = RegExp(g.pattern.source, v + "g");
                    }
                    for (
                      var w = g.pattern || g, A = a.next, E = u;
                      A !== n.tail && !(d && E >= d.reach);
                      E += A.value.length, A = A.next
                    ) {
                      var x = A.value;
                      if (n.length > t.length) return;
                      if (!(x instanceof s)) {
                        var k,
                          S = 1;
                        if (_) {
                          if (!(k = o(w, E, t, b)) || k.index >= t.length)
                            break;
                          var T = k.index,
                            P = k.index + k[0].length,
                            C = E;
                          for (C += A.value.length; T >= C; )
                            (A = A.next), (C += A.value.length);
                          if (
                            ((C -= A.value.length),
                            (E = C),
                            A.value instanceof s)
                          )
                            continue;
                          for (
                            var O = A;
                            O !== n.tail &&
                            (C < P || "string" == typeof O.value);
                            O = O.next
                          )
                            S++, (C += O.value.length);
                          S--, (x = t.slice(E, C)), (k.index -= E);
                        } else if (!(k = o(w, 0, x, b))) continue;
                        T = k.index;
                        var L = k[0],
                          F = x.slice(0, T),
                          D = x.slice(T + L.length),
                          j = E + x.length;
                        d && j > d.reach && (d.reach = j);
                        var I = A.prev;
                        F && ((I = l(n, I, F)), (E += F.length)), c(n, I, S);
                        var M = new s(h, m ? r.tokenize(L, m) : L, y, L);
                        if (((A = l(n, I, M)), D && l(n, A, D), S > 1)) {
                          var N = { cause: h + "," + p, reach: j };
                          e(t, n, i, A.prev, E, N),
                            d && N.reach > d.reach && (d.reach = N.reach);
                        }
                      }
                    }
                  }
                }
            })(e, u, t, u.head, 0),
            (function (e) {
              var t = [],
                n = e.head.next;
              for (; n !== e.tail; ) t.push(n.value), (n = n.next);
              return t;
            })(u)
          );
        },
        hooks: {
          all: {},
          add: function (e, t) {
            var n = r.hooks.all;
            (n[e] = n[e] || []), n[e].push(t);
          },
          run: function (e, t) {
            var n = r.hooks.all[e];
            if (n && n.length) for (var i, s = 0; (i = n[s++]); ) i(t);
          },
        },
        Token: s,
      };
    function s(e, t, n, i) {
      (this.type = e),
        (this.content = t),
        (this.alias = n),
        (this.length = 0 | (i || "").length);
    }
    function o(e, t, n, i) {
      e.lastIndex = t;
      var r = e.exec(n);
      if (r && i && r[1]) {
        var s = r[1].length;
        (r.index += s), (r[0] = r[0].slice(s));
      }
      return r;
    }
    function a() {
      var e = { value: null, prev: null, next: null },
        t = { value: null, prev: e, next: null };
      (e.next = t), (this.head = e), (this.tail = t), (this.length = 0);
    }
    function l(e, t, n) {
      var i = t.next,
        r = { value: n, prev: t, next: i };
      return (t.next = r), (i.prev = r), e.length++, r;
    }
    function c(e, t, n) {
      for (var i = t.next, r = 0; r < n && i !== e.tail; r++) i = i.next;
      (t.next = i), (i.prev = t), (e.length -= r);
    }
    if (
      ((e.Prism = r),
      (s.stringify = function e(t, n) {
        if ("string" == typeof t) return t;
        if (Array.isArray(t)) {
          var i = "";
          return (
            t.forEach(function (t) {
              i += e(t, n);
            }),
            i
          );
        }
        var s = {
            type: t.type,
            content: e(t.content, n),
            tag: "span",
            classes: ["token", t.type],
            attributes: {},
            language: n,
          },
          o = t.alias;
        o &&
          (Array.isArray(o)
            ? Array.prototype.push.apply(s.classes, o)
            : s.classes.push(o)),
          r.hooks.run("wrap", s);
        var a = "";
        for (var l in s.attributes)
          a +=
            " " +
            l +
            '="' +
            (s.attributes[l] || "").replace(/"/g, "&quot;") +
            '"';
        return (
          "<" +
          s.tag +
          ' class="' +
          s.classes.join(" ") +
          '"' +
          a +
          ">" +
          s.content +
          "</" +
          s.tag +
          ">"
        );
      }),
      !e.document)
    )
      return e.addEventListener
        ? (r.disableWorkerMessageHandler ||
            e.addEventListener(
              "message",
              function (t) {
                var n = JSON.parse(t.data),
                  i = n.language,
                  s = n.code,
                  o = n.immediateClose;
                e.postMessage(r.highlight(s, r.languages[i], i)),
                  o && e.close();
              },
              !1
            ),
          r)
        : r;
    var u = r.util.currentScript();
    function d() {
      r.manual || r.highlightAll();
    }
    if (
      (u &&
        ((r.filename = u.src),
        u.hasAttribute("data-manual") && (r.manual = !0)),
      !r.manual)
    ) {
      var h = document.readyState;
      "loading" === h || ("interactive" === h && u && u.defer)
        ? document.addEventListener("DOMContentLoaded", d)
        : window.requestAnimationFrame
        ? window.requestAnimationFrame(d)
        : window.setTimeout(d, 16);
    }
    return r;
  })(_self);
/**
 * Prism: Lightweight, robust, elegant syntax highlighting
 *
 * @license MIT <https://opensource.org/licenses/MIT>
 * @author Lea Verou <https://lea.verou.me>
 * @namespace
 * @public
 */ "undefined" != typeof module && module.exports && (module.exports = Prism),
  "undefined" != typeof global && (global.Prism = Prism),
  (Prism.languages.markup = {
    comment: { pattern: /<!--(?:(?!<!--)[\s\S])*?-->/, greedy: !0 },
    prolog: { pattern: /<\?[\s\S]+?\?>/, greedy: !0 },
    doctype: {
      pattern:
        /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null,
        },
        string: { pattern: /"[^"]*"|'[^']*'/, greedy: !0 },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/,
      },
    },
    cdata: { pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i, greedy: !0 },
    tag: {
      pattern:
        /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: { punctuation: /^<\/?/, namespace: /^[^\s>\/:]+:/ },
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              { pattern: /^=/, alias: "attr-equals" },
              { pattern: /^(\s*)["']|["']$/, lookbehind: !0 },
            ],
          },
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: { namespace: /^[^\s>\/:]+:/ },
        },
      },
    },
    entity: [
      { pattern: /&[\da-z]{1,8};/i, alias: "named-entity" },
      /&#x?[\da-f]{1,8};/i,
    ],
  }),
  (Prism.languages.markup.tag.inside["attr-value"].inside.entity =
    Prism.languages.markup.entity),
  (Prism.languages.markup.doctype.inside["internal-subset"].inside =
    Prism.languages.markup),
  Prism.hooks.add("wrap", function (e) {
    "entity" === e.type &&
      (e.attributes.title = e.content.replace(/&amp;/, "&"));
  }),
  Object.defineProperty(Prism.languages.markup.tag, "addInlined", {
    value: function (e, t) {
      var n = {};
      (n["language-" + t] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: Prism.languages[t],
      }),
        (n.cdata = /^<!\[CDATA\[|\]\]>$/i);
      var i = {
        "included-cdata": { pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i, inside: n },
      };
      i["language-" + t] = { pattern: /[\s\S]+/, inside: Prism.languages[t] };
      var r = {};
      (r[e] = {
        pattern: RegExp(
          /(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(
            /__/g,
            function () {
              return e;
            }
          ),
          "i"
        ),
        lookbehind: !0,
        greedy: !0,
        inside: i,
      }),
        Prism.languages.insertBefore("markup", "cdata", r);
    },
  }),
  Object.defineProperty(Prism.languages.markup.tag, "addAttribute", {
    value: function (e, t) {
      Prism.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source +
            "(?:" +
            e +
            ")" +
            /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [t, "language-" + t],
                inside: Prism.languages[t],
              },
              punctuation: [{ pattern: /^=/, alias: "attr-equals" }, /"|'/],
            },
          },
        },
      });
    },
  }),
  (Prism.languages.html = Prism.languages.markup),
  (Prism.languages.mathml = Prism.languages.markup),
  (Prism.languages.svg = Prism.languages.markup),
  (Prism.languages.xml = Prism.languages.extend("markup", {})),
  (Prism.languages.ssml = Prism.languages.xml),
  (Prism.languages.atom = Prism.languages.xml),
  (Prism.languages.rss = Prism.languages.xml),
  (function (e) {
    var t =
      /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    (e.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: RegExp(
          "@[\\w-](?:" +
            /[^;{\s"']|\s+(?!\s)/.source +
            "|" +
            t.source +
            ")*?" +
            /(?:;|(?=\s*\{))/.source
        ),
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern:
              /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector",
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0,
          },
        },
      },
      url: {
        pattern: RegExp(
          "\\burl\\((?:" +
            t.source +
            "|" +
            /(?:[^\\\r\n()"']|\\[\s\S])*/.source +
            ")\\)",
          "i"
        ),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: { pattern: RegExp("^" + t.source + "$"), alias: "url" },
        },
      },
      selector: {
        pattern: RegExp(
          "(^|[{}\\s])[^{}\\s](?:[^{};\"'\\s]|\\s+(?![\\s{])|" +
            t.source +
            ")*(?=\\s*\\{)"
        ),
        lookbehind: !0,
      },
      string: { pattern: t, greedy: !0 },
      property: {
        pattern:
          /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0,
      },
      important: /!important\b/i,
      function: { pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i, lookbehind: !0 },
      punctuation: /[(){};:,]/,
    }),
      (e.languages.css.atrule.inside.rest = e.languages.css);
    var n = e.languages.markup;
    n && (n.tag.addInlined("style", "css"), n.tag.addAttribute("style", "css"));
  })(Prism),
  (Prism.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0,
      },
      { pattern: /(^|[^\\:])\/\/.*/, lookbehind: !0, greedy: !0 },
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0,
    },
    "class-name": {
      pattern:
        /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: { punctuation: /[.\\]/ },
    },
    keyword:
      /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/,
  }),
  (Prism.languages.javascript = Prism.languages.extend("clike", {
    "class-name": [
      Prism.languages.clike["class-name"],
      {
        pattern:
          /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0,
      },
    ],
    keyword: [
      { pattern: /((?:^|\})\s*)catch\b/, lookbehind: !0 },
      {
        pattern:
          /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0,
      },
    ],
    function:
      /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source +
          "(?:" +
          /NaN|Infinity/.source +
          "|" +
          /0[bB][01]+(?:_[01]+)*n?/.source +
          "|" +
          /0[oO][0-7]+(?:_[0-7]+)*n?/.source +
          "|" +
          /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source +
          "|" +
          /\d+(?:_\d+)*n/.source +
          "|" +
          /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/
            .source +
          ")" +
          /(?![\w$])/.source
      ),
      lookbehind: !0,
    },
    operator:
      /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/,
  })),
  (Prism.languages.javascript["class-name"][0].pattern =
    /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/),
  Prism.languages.insertBefore("javascript", "keyword", {
    regex: {
      pattern: RegExp(
        /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source +
          /\//.source +
          "(?:" +
          /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/
            .source +
          "|" +
          /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/
            .source +
          ")" +
          /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/
            .source
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: Prism.languages.regex,
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/,
      },
    },
    "function-variable": {
      pattern:
        /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function",
    },
    parameter: [
      {
        pattern:
          /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: Prism.languages.javascript,
      },
      {
        pattern:
          /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: Prism.languages.javascript,
      },
      {
        pattern:
          /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: Prism.languages.javascript,
      },
      {
        pattern:
          /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: Prism.languages.javascript,
      },
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/,
  }),
  Prism.languages.insertBefore("javascript", "string", {
    hashbang: { pattern: /^#!.*/, greedy: !0, alias: "comment" },
    "template-string": {
      pattern:
        /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": { pattern: /^`|`$/, alias: "string" },
        interpolation: {
          pattern:
            /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation",
            },
            rest: Prism.languages.javascript,
          },
        },
        string: /[\s\S]+/,
      },
    },
    "string-property": {
      pattern:
        /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property",
    },
  }),
  Prism.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern:
        /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property",
    },
  }),
  Prism.languages.markup &&
    (Prism.languages.markup.tag.addInlined("script", "javascript"),
    Prism.languages.markup.tag.addAttribute(
      /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/
        .source,
      "javascript"
    )),
  (Prism.languages.js = Prism.languages.javascript),
  (function () {
    if (void 0 !== Prism && "undefined" != typeof document) {
      Element.prototype.matches ||
        (Element.prototype.matches =
          Element.prototype.msMatchesSelector ||
          Element.prototype.webkitMatchesSelector);
      var e = {
          js: "javascript",
          py: "python",
          rb: "ruby",
          ps1: "powershell",
          psm1: "powershell",
          sh: "bash",
          bat: "batch",
          h: "c",
          tex: "latex",
        },
        t =
          'pre[data-src]:not([data-src-status="loaded"]):not([data-src-status="loading"])';
      Prism.hooks.add("before-highlightall", function (e) {
        e.selector += ", " + t;
      }),
        Prism.hooks.add("before-sanity-check", function (n) {
          var i = n.element;
          if (i.matches(t)) {
            (n.code = ""), i.setAttribute("data-src-status", "loading");
            var r = i.appendChild(document.createElement("CODE"));
            r.textContent = "Loading…";
            var s = i.getAttribute("data-src"),
              o = n.language;
            if ("none" === o) {
              var a = (/\.(\w+)$/.exec(s) || [, "none"])[1];
              o = e[a] || a;
            }
            Prism.util.setLanguage(r, o), Prism.util.setLanguage(i, o);
            var l = Prism.plugins.autoloader;
            l && l.loadLanguages(o),
              (function (e, t, n) {
                var i = new XMLHttpRequest();
                i.open("GET", e, !0),
                  (i.onreadystatechange = function () {
                    var e, r;
                    4 == i.readyState &&
                      (i.status < 400 && i.responseText
                        ? t(i.responseText)
                        : i.status >= 400
                        ? n(
                            ((e = i.status),
                            (r = i.statusText),
                            "✖ Error " + e + " while fetching file: " + r)
                          )
                        : n("✖ Error: File does not exist or is empty"));
                  }),
                  i.send(null);
              })(
                s,
                function (e) {
                  i.setAttribute("data-src-status", "loaded");
                  var t = (function (e) {
                    var t = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(
                      e || ""
                    );
                    if (t) {
                      var n = Number(t[1]),
                        i = t[2],
                        r = t[3];
                      return i ? (r ? [n, Number(r)] : [n, void 0]) : [n, n];
                    }
                  })(i.getAttribute("data-range"));
                  if (t) {
                    var n = e.split(/\r\n?|\n/g),
                      s = t[0],
                      o = null == t[1] ? n.length : t[1];
                    s < 0 && (s += n.length),
                      (s = Math.max(0, Math.min(s - 1, n.length))),
                      o < 0 && (o += n.length),
                      (o = Math.max(0, Math.min(o, n.length))),
                      (e = n.slice(s, o).join("\n")),
                      i.hasAttribute("data-start") ||
                        i.setAttribute("data-start", String(s + 1));
                  }
                  (r.textContent = e), Prism.highlightElement(r);
                },
                function (e) {
                  i.setAttribute("data-src-status", "failed"),
                    (r.textContent = e);
                }
              );
          }
        }),
        (Prism.plugins.fileHighlight = {
          highlight: function (e) {
            for (
              var n, i = (e || document).querySelectorAll(t), r = 0;
              (n = i[r++]);

            )
              Prism.highlightElement(n);
          },
        });
      var n = !1;
      Prism.fileHighlight = function () {
        n ||
          (console.warn(
            "Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."
          ),
          (n = !0)),
          Prism.plugins.fileHighlight.highlight.apply(this, arguments);
      };
    }
  })(),
  (function (e, t) {
    "object" == typeof exports && "object" == typeof module
      ? (module.exports = t())
      : "function" == typeof define && define.amd
      ? define([], t)
      : "object" == typeof exports
      ? (exports.ClipboardJS = t())
      : (e.ClipboardJS = t());
  })(this, function () {
    return (
      (t = {
        686: function (e, t, n) {
          "use strict";
          n.d(t, {
            default: function () {
              return m;
            },
          });
          t = n(279);
          var i = n.n(t),
            r = ((t = n(370)), n.n(t)),
            s = ((t = n(817)), n.n(t));
          function o(e) {
            try {
              return document.execCommand(e);
            } catch (e) {
              return;
            }
          }
          var a = function (e) {
            return (e = s()(e)), o("cut"), e;
          };
          function l(e, t) {
            var n, i;
            (n = e),
              (i = "rtl" === document.documentElement.getAttribute("dir")),
              ((e = document.createElement("textarea")).style.fontSize =
                "12pt"),
              (e.style.border = "0"),
              (e.style.padding = "0"),
              (e.style.margin = "0"),
              (e.style.position = "absolute"),
              (e.style[i ? "right" : "left"] = "-9999px"),
              (i = window.pageYOffset || document.documentElement.scrollTop),
              (e.style.top = "".concat(i, "px")),
              e.setAttribute("readonly", ""),
              (e.value = n),
              (e = e);
            return (
              t.container.appendChild(e), (t = s()(e)), o("copy"), e.remove(), t
            );
          }
          var c = function (e) {
            var t =
                1 < arguments.length && void 0 !== arguments[1]
                  ? arguments[1]
                  : { container: document.body },
              n = "";
            return (
              "string" == typeof e
                ? (n = l(e, t))
                : e instanceof HTMLInputElement &&
                  !["text", "search", "url", "tel", "password"].includes(
                    null == e ? void 0 : e.type
                  )
                ? (n = l(e.value, t))
                : ((n = s()(e)), o("copy")),
              n
            );
          };
          function u(e) {
            return (u =
              "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
                ? function (e) {
                    return typeof e;
                  }
                : function (e) {
                    return e &&
                      "function" == typeof Symbol &&
                      e.constructor === Symbol &&
                      e !== Symbol.prototype
                      ? "symbol"
                      : typeof e;
                  })(e);
          }
          function d(e) {
            return (d =
              "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
                ? function (e) {
                    return typeof e;
                  }
                : function (e) {
                    return e &&
                      "function" == typeof Symbol &&
                      e.constructor === Symbol &&
                      e !== Symbol.prototype
                      ? "symbol"
                      : typeof e;
                  })(e);
          }
          function h(e, t) {
            for (var n = 0; n < t.length; n++) {
              var i = t[n];
              (i.enumerable = i.enumerable || !1),
                (i.configurable = !0),
                "value" in i && (i.writable = !0),
                Object.defineProperty(e, i.key, i);
            }
          }
          function f(e, t) {
            return (f =
              Object.setPrototypeOf ||
              function (e, t) {
                return (e.__proto__ = t), e;
              })(e, t);
          }
          function p(e) {
            return (p = Object.setPrototypeOf
              ? Object.getPrototypeOf
              : function (e) {
                  return e.__proto__ || Object.getPrototypeOf(e);
                })(e);
          }
          function g(e, t) {
            if (((e = "data-clipboard-".concat(e)), t.hasAttribute(e)))
              return t.getAttribute(e);
          }
          var m = (function () {
            !(function (e, t) {
              if ("function" != typeof t && null !== t)
                throw new TypeError(
                  "Super expression must either be null or a function"
                );
              (e.prototype = Object.create(t && t.prototype, {
                constructor: { value: e, writable: !0, configurable: !0 },
              })),
                t && f(e, t);
            })(o, i());
            var e,
              t,
              n,
              s = (function (e) {
                var t = (function () {
                  if ("undefined" == typeof Reflect || !Reflect.construct)
                    return !1;
                  if (Reflect.construct.sham) return !1;
                  if ("function" == typeof Proxy) return !0;
                  try {
                    return (
                      Date.prototype.toString.call(
                        Reflect.construct(Date, [], function () {})
                      ),
                      !0
                    );
                  } catch (e) {
                    return !1;
                  }
                })();
                return function () {
                  var n,
                    i = p(e);
                  return (
                    (n = t
                      ? ((n = p(this).constructor),
                        Reflect.construct(i, arguments, n))
                      : i.apply(this, arguments)),
                    (i = this),
                    !(n = n) || ("object" !== d(n) && "function" != typeof n)
                      ? (function (e) {
                          if (void 0 !== e) return e;
                          throw new ReferenceError(
                            "this hasn't been initialised - super() hasn't been called"
                          );
                        })(i)
                      : n
                  );
                };
              })(o);
            function o(e, t) {
              var n;
              return (
                (function (e) {
                  if (!(e instanceof o))
                    throw new TypeError("Cannot call a class as a function");
                })(this),
                (n = s.call(this)).resolveOptions(t),
                n.listenClick(e),
                n
              );
            }
            return (
              (e = o),
              (n = [
                {
                  key: "copy",
                  value: function (e) {
                    var t =
                      1 < arguments.length && void 0 !== arguments[1]
                        ? arguments[1]
                        : { container: document.body };
                    return c(e, t);
                  },
                },
                {
                  key: "cut",
                  value: function (e) {
                    return a(e);
                  },
                },
                {
                  key: "isSupported",
                  value: function () {
                    var e =
                        "string" ==
                        typeof (e =
                          0 < arguments.length && void 0 !== arguments[0]
                            ? arguments[0]
                            : ["copy", "cut"])
                          ? [e]
                          : e,
                      t = !!document.queryCommandSupported;
                    return (
                      e.forEach(function (e) {
                        t = t && !!document.queryCommandSupported(e);
                      }),
                      t
                    );
                  },
                },
              ]),
              (t = [
                {
                  key: "resolveOptions",
                  value: function () {
                    var e =
                      0 < arguments.length && void 0 !== arguments[0]
                        ? arguments[0]
                        : {};
                    (this.action =
                      "function" == typeof e.action
                        ? e.action
                        : this.defaultAction),
                      (this.target =
                        "function" == typeof e.target
                          ? e.target
                          : this.defaultTarget),
                      (this.text =
                        "function" == typeof e.text
                          ? e.text
                          : this.defaultText),
                      (this.container =
                        "object" === d(e.container)
                          ? e.container
                          : document.body);
                  },
                },
                {
                  key: "listenClick",
                  value: function (e) {
                    var t = this;
                    this.listener = r()(e, "click", function (e) {
                      return t.onClick(e);
                    });
                  },
                },
                {
                  key: "onClick",
                  value: function (e) {
                    var t = e.delegateTarget || e.currentTarget,
                      n = this.action(t) || "copy";
                    e = (function () {
                      var e =
                          void 0 ===
                          (n = (i =
                            0 < arguments.length && void 0 !== arguments[0]
                              ? arguments[0]
                              : {}).action)
                            ? "copy"
                            : n,
                        t = i.container,
                        n = i.target,
                        i = i.text;
                      if ("copy" !== e && "cut" !== e)
                        throw new Error(
                          'Invalid "action" value, use either "copy" or "cut"'
                        );
                      if (void 0 !== n) {
                        if (!n || "object" !== u(n) || 1 !== n.nodeType)
                          throw new Error(
                            'Invalid "target" value, use a valid Element'
                          );
                        if ("copy" === e && n.hasAttribute("disabled"))
                          throw new Error(
                            'Invalid "target" attribute. Please use "readonly" instead of "disabled" attribute'
                          );
                        if (
                          "cut" === e &&
                          (n.hasAttribute("readonly") ||
                            n.hasAttribute("disabled"))
                        )
                          throw new Error(
                            'Invalid "target" attribute. You can\'t cut text from elements with "readonly" or "disabled" attributes'
                          );
                      }
                      return i
                        ? c(i, { container: t })
                        : n
                        ? "cut" === e
                          ? a(n)
                          : c(n, { container: t })
                        : void 0;
                    })({
                      action: n,
                      container: this.container,
                      target: this.target(t),
                      text: this.text(t),
                    });
                    this.emit(e ? "success" : "error", {
                      action: n,
                      text: e,
                      trigger: t,
                      clearSelection: function () {
                        t && t.focus(), window.getSelection().removeAllRanges();
                      },
                    });
                  },
                },
                {
                  key: "defaultAction",
                  value: function (e) {
                    return g("action", e);
                  },
                },
                {
                  key: "defaultTarget",
                  value: function (e) {
                    if ((e = g("target", e))) return document.querySelector(e);
                  },
                },
                {
                  key: "defaultText",
                  value: function (e) {
                    return g("text", e);
                  },
                },
                {
                  key: "destroy",
                  value: function () {
                    this.listener.destroy();
                  },
                },
              ]) && h(e.prototype, t),
              n && h(e, n),
              o
            );
          })();
        },
        828: function (e) {
          var t;
          "undefined" == typeof Element ||
            Element.prototype.matches ||
            ((t = Element.prototype).matches =
              t.matchesSelector ||
              t.mozMatchesSelector ||
              t.msMatchesSelector ||
              t.oMatchesSelector ||
              t.webkitMatchesSelector),
            (e.exports = function (e, t) {
              for (; e && 9 !== e.nodeType; ) {
                if ("function" == typeof e.matches && e.matches(t)) return e;
                e = e.parentNode;
              }
            });
        },
        438: function (e, t, n) {
          var i = n(828);
          function r(e, t, n, r, s) {
            var o = function (e, t, n, r) {
              return function (n) {
                (n.delegateTarget = i(n.target, t)),
                  n.delegateTarget && r.call(e, n);
              };
            }.apply(this, arguments);
            return (
              e.addEventListener(n, o, s),
              {
                destroy: function () {
                  e.removeEventListener(n, o, s);
                },
              }
            );
          }
          e.exports = function (e, t, n, i, s) {
            return "function" == typeof e.addEventListener
              ? r.apply(null, arguments)
              : "function" == typeof n
              ? r.bind(null, document).apply(null, arguments)
              : ("string" == typeof e && (e = document.querySelectorAll(e)),
                Array.prototype.map.call(e, function (e) {
                  return r(e, t, n, i, s);
                }));
          };
        },
        879: function (e, t) {
          (t.node = function (e) {
            return void 0 !== e && e instanceof HTMLElement && 1 === e.nodeType;
          }),
            (t.nodeList = function (e) {
              var n = Object.prototype.toString.call(e);
              return (
                void 0 !== e &&
                ("[object NodeList]" === n ||
                  "[object HTMLCollection]" === n) &&
                "length" in e &&
                (0 === e.length || t.node(e[0]))
              );
            }),
            (t.string = function (e) {
              return "string" == typeof e || e instanceof String;
            }),
            (t.fn = function (e) {
              return "[object Function]" === Object.prototype.toString.call(e);
            });
        },
        370: function (e, t, n) {
          var i = n(879),
            r = n(438);
          e.exports = function (e, t, n) {
            if (!e && !t && !n) throw new Error("Missing required arguments");
            if (!i.string(t))
              throw new TypeError("Second argument must be a String");
            if (!i.fn(n))
              throw new TypeError("Third argument must be a Function");
            if (i.node(e))
              return (
                (c = t),
                (u = n),
                (l = e).addEventListener(c, u),
                {
                  destroy: function () {
                    l.removeEventListener(c, u);
                  },
                }
              );
            if (i.nodeList(e))
              return (
                (s = e),
                (o = t),
                (a = n),
                Array.prototype.forEach.call(s, function (e) {
                  e.addEventListener(o, a);
                }),
                {
                  destroy: function () {
                    Array.prototype.forEach.call(s, function (e) {
                      e.removeEventListener(o, a);
                    });
                  },
                }
              );
            if (i.string(e))
              return (e = e), (t = t), (n = n), r(document.body, e, t, n);
            throw new TypeError(
              "First argument must be a String, HTMLElement, HTMLCollection, or NodeList"
            );
            var s, o, a, l, c, u;
          };
        },
        817: function (e) {
          e.exports = function (e) {
            var t,
              n =
                "SELECT" === e.nodeName
                  ? (e.focus(), e.value)
                  : "INPUT" === e.nodeName || "TEXTAREA" === e.nodeName
                  ? ((t = e.hasAttribute("readonly")) ||
                      e.setAttribute("readonly", ""),
                    e.select(),
                    e.setSelectionRange(0, e.value.length),
                    t || e.removeAttribute("readonly"),
                    e.value)
                  : (e.hasAttribute("contenteditable") && e.focus(),
                    (n = window.getSelection()),
                    (t = document.createRange()).selectNodeContents(e),
                    n.removeAllRanges(),
                    n.addRange(t),
                    n.toString());
            return n;
          };
        },
        279: function (e) {
          function t() {}
          (t.prototype = {
            on: function (e, t, n) {
              var i = this.e || (this.e = {});
              return (i[e] || (i[e] = [])).push({ fn: t, ctx: n }), this;
            },
            once: function (e, t, n) {
              var i = this;
              function r() {
                i.off(e, r), t.apply(n, arguments);
              }
              return (r._ = t), this.on(e, r, n);
            },
            emit: function (e) {
              for (
                var t = [].slice.call(arguments, 1),
                  n = ((this.e || (this.e = {}))[e] || []).slice(),
                  i = 0,
                  r = n.length;
                i < r;
                i++
              )
                n[i].fn.apply(n[i].ctx, t);
              return this;
            },
            off: function (e, t) {
              var n = this.e || (this.e = {}),
                i = n[e],
                r = [];
              if (i && t)
                for (var s = 0, o = i.length; s < o; s++)
                  i[s].fn !== t && i[s].fn._ !== t && r.push(i[s]);
              return r.length ? (n[e] = r) : delete n[e], this;
            },
          }),
            (e.exports = t),
            (e.exports.TinyEmitter = t);
        },
      }),
      (n = {}),
      (e.n = function (t) {
        var n =
          t && t.__esModule
            ? function () {
                return t.default;
              }
            : function () {
                return t;
              };
        return e.d(n, { a: n }), n;
      }),
      (e.d = function (t, n) {
        for (var i in n)
          e.o(n, i) &&
            !e.o(t, i) &&
            Object.defineProperty(t, i, { enumerable: !0, get: n[i] });
      }),
      (e.o = function (e, t) {
        return Object.prototype.hasOwnProperty.call(e, t);
      }),
      e(686).default
    );
    function e(i) {
      if (n[i]) return n[i].exports;
      var r = (n[i] = { exports: {} });
      return t[i](r, r.exports, e), r.exports;
    }
    var t, n;
  });
/*!
 * NioApp v1.0.0 (https://softnio.com/)
 * Developed by Softnio Team.
 * Copyright by Softnio.
 */
var NioApp = (function (e, t) {
  "use strict";
  var n = {
    AppInfo: { name: "NioApp", version: "1.0.0", author: "Softnio" },
    Package: { name: "products", version: "1.0" },
  };
  return (
    (n.docReady = function (e) {
      document.addEventListener("DOMContentLoaded", e, !1);
    }),
    (n.winLoad = function (e) {
      window.addEventListener("load", e, !1);
    }),
    (n.onResize = function (e, t) {
      (t = void 0 === t ? window : t).addEventListener("resize", e);
    }),
    n
  );
})(window, document);
NioApp = (function (e) {
  "use strict";
  return (
    (e.BS = {}),
    (e.Addons = {}),
    (e.Custom = {}),
    (e.body = document.querySelector("body")),
    (e.Win = { height: window.innerHeight, width: window.innerWidth }),
    (e.Break = {
      mb: 420,
      sm: 576,
      md: 768,
      lg: 992,
      xl: 1200,
      xxl: 1540,
      any: 1 / 0,
    }),
    (e.isDark = !!e.body.classList.contains("dark-mode")),
    (e.monthList = [
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December",
    ]),
    (e.docStyle = getComputedStyle(document.documentElement)),
    (e.Colors = {
      blue: e.docStyle.getPropertyValue("--bs-blue"),
      indigo: e.docStyle.getPropertyValue("--bs-indigo"),
      purple: e.docStyle.getPropertyValue("--bs-purple"),
      pink: e.docStyle.getPropertyValue("--bs-pink"),
      red: e.docStyle.getPropertyValue("--bs-red"),
      orange: e.docStyle.getPropertyValue("--bs-orange"),
      yellow: e.docStyle.getPropertyValue("--bs-yellow"),
      green: e.docStyle.getPropertyValue("--bs-green"),
      teal: e.docStyle.getPropertyValue("--bs-teal"),
      cyan: e.docStyle.getPropertyValue("--bs-cyan"),
      black: e.docStyle.getPropertyValue("--bs-black"),
      white: e.docStyle.getPropertyValue("--bs-white"),
      gray: e.docStyle.getPropertyValue("--bs-gray"),
      grayDark: e.docStyle.getPropertyValue("--bs-gray-dark"),
      gray100: e.docStyle.getPropertyValue("--bs-gray-100"),
      gray200: e.docStyle.getPropertyValue("--bs-gray-200"),
      gray300: e.docStyle.getPropertyValue("--bs-gray-300"),
      gray400: e.docStyle.getPropertyValue("--bs-gray-400"),
      gray500: e.docStyle.getPropertyValue("--bs-gray-500"),
      gray600: e.docStyle.getPropertyValue("--bs-gray-600"),
      gray700: e.docStyle.getPropertyValue("--bs-gray-700"),
      gray800: e.docStyle.getPropertyValue("--bs-gray-800"),
      gray900: e.docStyle.getPropertyValue("--bs-gray-900"),
      primary: e.docStyle.getPropertyValue("--bs-primary"),
      secondary: e.docStyle.getPropertyValue("--bs-secondary"),
      success: e.docStyle.getPropertyValue("--bs-success"),
      info: e.docStyle.getPropertyValue("--bs-info"),
      warning: e.docStyle.getPropertyValue("--bs-warning"),
      danger: e.docStyle.getPropertyValue("--bs-danger"),
      light: e.docStyle.getPropertyValue("--bs-light"),
      dark: e.docStyle.getPropertyValue("--bs-dark"),
      darker: e.docStyle.getPropertyValue("--bs-darker"),
      bodyColor: e.docStyle.getPropertyValue("--bs-body-color"),
      bodyBg: e.docStyle.getPropertyValue("--bs-body-bg"),
      borderColor: e.docStyle.getPropertyValue("--bs-border-color"),
      borderColorTranslucent: e.docStyle.getPropertyValue(
        "--bs-border-color-translucent"
      ),
      headingColor: e.docStyle.getPropertyValue("--bs-heading-color"),
      linkColor: e.docStyle.getPropertyValue("--bs-link-color"),
      linkHoverColor: e.docStyle.getPropertyValue("--bs-link-hover-color"),
      codeColor: e.docStyle.getPropertyValue("--bs-code-color"),
      highlightBg: e.docStyle.getPropertyValue("--bs-highlight-bg"),
    }),
    (e.State = {
      isRTL: !(
        !e.body.classList.contains("has-rtl") &&
        "rtl" !== e.body.getAttribute("dir")
      ),
      isTouch: "ontouchstart" in document.documentElement,
      isMobile: !!navigator.userAgent.match(
        /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini|Windows Phone|/i
      ),
      asMobile: e.Win.width < e.Break.md,
    }),
    (e.StateUpdate = function () {
      (e.Win = { height: window.innerHeight, width: window.innerWidth }),
        (e.State.asMobile = e.Win.width < e.Break.md);
    }),
    (e.hexRGB = function (e, t) {
      var n,
        i,
        r = t || 1;
      if (((e = e.replace(/\s/g, "")), /^#([A-Fa-f0-9]{3}){1,2}$/.test(e)))
        return (
          3 === (n = e.substring(1).split("")).length &&
            (n = [n[0], n[0], n[1], n[1], n[2], n[2]]),
          (i = [
            ((n = "0x" + n.join("")) >> 16) & 255,
            (n >> 8) & 255,
            255 & n,
          ].join(",")),
          r >= 1 ? "rgba(" + i + ")" : "rgba(" + i + "," + r + ")"
        );
      throw new Error("bad hex");
    }),
    (e.to12 = function (e) {
      return (
        (e = e.toString().match(/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [
          e,
        ]).length > 1 &&
          ((e = e.slice(1)).pop(),
          (e[5] = +e[0] < 12 ? " AM" : " PM"),
          (e[0] = +e[0] % 12 || 12)),
        (e = e.join(""))
      );
    }),
    (e.attr = function (e, t, n) {
      const i = document.createAttribute(t);
      (i.value = n), e.setAttributeNode(i);
    }),
    (e.SlideUp = function (e, t = 500) {
      (e.style.transitionProperty = "height, margin, padding"),
        (e.style.transitionDuration = t + "ms"),
        (e.style.boxSizing = "border-box"),
        (e.style.height = e.offsetHeight + "px"),
        e.offsetHeight,
        (e.style.overflow = "hidden"),
        (e.style.height = 0),
        (e.style.paddingTop = 0),
        (e.style.paddingBottom = 0),
        (e.style.marginTop = 0),
        (e.style.marginBottom = 0),
        window.setTimeout(() => {
          (e.style.display = "none"),
            e.style.removeProperty("height"),
            e.style.removeProperty("padding-top"),
            e.style.removeProperty("padding-bottom"),
            e.style.removeProperty("margin-top"),
            e.style.removeProperty("margin-bottom"),
            e.style.removeProperty("overflow"),
            e.style.removeProperty("transition-duration"),
            e.style.removeProperty("transition-property");
        }, t);
    }),
    (e.SlideDown = function (e, t = 500) {
      e.style.removeProperty("display");
      let n = window.getComputedStyle(e).display;
      "none" === n && (n = "block"), (e.style.display = n);
      let i = e.offsetHeight;
      (e.style.overflow = "hidden"),
        (e.style.height = 0),
        (e.style.paddingTop = 0),
        (e.style.paddingBottom = 0),
        (e.style.marginTop = 0),
        (e.style.marginBottom = 0),
        e.offsetHeight,
        (e.style.boxSizing = "border-box"),
        (e.style.transitionProperty = "height, margin, padding"),
        (e.style.transitionDuration = t + "ms"),
        (e.style.height = i + "px"),
        e.style.removeProperty("padding-top"),
        e.style.removeProperty("padding-bottom"),
        e.style.removeProperty("margin-top"),
        e.style.removeProperty("margin-bottom"),
        window.setTimeout(() => {
          e.style.removeProperty("height"),
            e.style.removeProperty("overflow"),
            e.style.removeProperty("transition-duration"),
            e.style.removeProperty("transition-property");
        }, t);
    }),
    (e.SlideToggle = function (t, n = 500) {
      return "none" === window.getComputedStyle(t).display
        ? e.SlideDown(t, n)
        : e.SlideUp(t, n);
    }),
    (e.toMin = function (e) {
      let t = e.split(":");
      return 60 * parseInt(t[0]) + (void 0 !== t[1] ? parseInt(t[1]) : 0);
    }),
    (e.toTime = function (e) {
      const t = e % 60;
      return `${Math.floor(e / 60)
        .toString()
        .padStart(2, "0")}:${t.toString().padStart(2, "0")}`;
    }),
    (e.randomId = function (e) {
      for (
        var t = "",
          n = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",
          i = n.length,
          r = 0;
        r < e;
        r++
      )
        t += n.charAt(Math.floor(Math.random() * i));
      return t;
    }),
    (e.getParents = function (e, t, n) {
      let i = void 0 === t ? document : document.querySelector(t);
      for (var r = [], s = e.parentNode; s !== i; ) {
        var o = s;
        (void 0 === n || o.classList.contains(n)) && r.push(o),
          (s = o.parentNode);
      }
      return r;
    }),
    (e.extendObject = function (e, t) {
      return (
        Object.keys(t).forEach(function (n) {
          e[n] = t[n];
        }),
        e
      );
    }),
    (e.Custom.timePicker = function (t, n) {
      let i = {
          format: n.format ? n.format : 24,
          interval: n.interval ? n.interval : 30,
          start: n.start ? n.start : "00:00",
          end: n.end ? n.end : "23:59",
          class: {
            dropdown: "nk-timepicker-dropdown",
            dropdownItem: "nk-timepicker-time",
          },
        },
        r = i.interval,
        s = i.format,
        o = i.start,
        a = i.end,
        l = e.toMin(a) - e.toMin(o),
        c = Math.floor(l / r),
        u = [],
        d = e.toMin(o);
      for (let t = 0; t < c + 1; t++) {
        let t = d,
          n = function () {
            return 12 == s ? e.to12(e.toTime(t)) : e.toTime(t);
          };
        u.push(
          `<li><button class="dropdown-item ${
            i.class.dropdownItem
          }" data-picker-text="${n()}" type="button">\n                ${n()}\n            </button></li>`
        ),
          (d = t + r);
      }
      let h = u.join("");
      e.attr(t, "data-bs-toggle", "dropdown"),
        e.attr(t, "data-bs-offset", "0,5");
      let f = t.id ? t.id : e.randomId(8);
      t.id || e.attr(t, "id", f);
      let p = `\n        <ul class="dropdown-menu ${i.class.dropdown}" data-picker-id="${f}" style="max-height:320px;overflow:auto">\n            ${h}\n        </ul>\n        `;
      t.insertAdjacentHTML("afterend", p),
        document.querySelectorAll("." + i.class.dropdownItem).forEach((e) => {
          e.addEventListener("click", function (t) {
            t.preventDefault();
            let n = e.dataset.pickerText;
            (document.getElementById(
              e.closest("." + i.class.dropdown).dataset.pickerId
            ).value = n),
              e
                .closest("." + i.class.dropdown)
                .querySelectorAll("." + i.class.dropdownItem)
                .forEach((e) => {
                  e.classList.remove("active");
                }),
              e.classList.add("active");
          });
        });
    }),
    (e.BS.tooltip = function (e) {
      let t = document.querySelectorAll(e);
      [].slice.call(t).map(function (e) {
        return new bootstrap.Tooltip(e);
      });
    }),
    (e.BS.popover = function (e) {
      const t = [].slice.call(document.querySelectorAll(e));
      if (null !== t) {
        t.map(function (e) {
          return new bootstrap.Popover(e);
        });
      }
    }),
    (e.BS.toast = function (e) {
      const t = document.querySelectorAll(e);
      t.length > 0 &&
        t.forEach((e) => {
          let t = e.dataset.bsTarget;
          const n = document.getElementById(t);
          e.addEventListener("click", function () {
            new bootstrap.Toast(n).show();
          });
        });
    }),
    (e.BS.alertTemplate = function (e, t, n) {
      const i = document.getElementById(e),
        r = document.createElement("div");
      (r.innerHTML = `<div class="alert alert-${
        n || "primary"
      } alert-dismissible" role="alert">\n                <div>${t}</div>\n                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>\n        </div>`),
        i.append(r);
    }),
    (e.BS.alert = function (t, n) {
      const i = document.querySelectorAll(t);
      i.length > 0 &&
        i.forEach((t) => {
          const i = t.dataset.bsTarget ? t.dataset.bsTarget : n.target,
            r = t.dataset.bsVariant ? t.dataset.bsVariant : n.variant,
            s = t.dataset.bsContent ? t.dataset.bsContent : n.content;
          t.addEventListener("click", function () {
            e.BS.alertTemplate(i, s, r);
          });
        });
    }),
    (e.BS.validate = function (e) {
      const t = document.querySelectorAll(e);
      Array.from(t).forEach((e) => {
        e.addEventListener(
          "submit",
          (t) => {
            e.checkValidity() || (t.preventDefault(), t.stopPropagation()),
              e.classList.add("was-validated");
          },
          !1
        );
      });
    }),
    e.onResize(e.StateUpdate),
    e
  );
})(NioApp);
