<?php $__env->startSection('title', 'All Projects'); ?>
<?php $__env->startSection('content'); ?>


    <!-- BEGIN: Content-->
    <div class="app-content content ">
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
        <div class="content-wrapper">
            <div class="content-header row">
                <div class="content-header-left col-md-9 col-12 mb-2">
                    <div class="row breadcrumbs-top">
                        <div class="col-12">
                            <h2 class="content-header-title float-left mb-0">All Project</h2>
                            <div class="breadcrumb-wrapper">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>
                                    </li>
                                    <li class="breadcrumb-item active">All Projects
                                    </li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="content-header-right text-md-right col-md-3 col-12 d-md-block d-none">
                    <div class="card-options">
                        <a href="<?php echo e(route('admin.project.create')); ?>" class="btn btn-primary mr-1">
                            Add Project
                        </a>
                    </div>
                </div>
            </div>
            <div class="content-body">
                <div class="row" id="basic-table">
                    <div class="col-12">
                        <div class="card">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th style="text-align: center;">#No</th>
                                            <th style="text-align: center;">Media</th>
                                            <th>Project Title</th>
                                            <th style="text-align: center;">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr style="vertical-align: middle;">
                                                <th style="text-align: center;" scope="row">
                                                    <?php echo e($key + 1); ?></th>
                                                <td style="text-align: center;">
                                                    <img src="<?php echo e(url('project/preview/' . $project->preview_img)); ?>"
                                                        class="img-responsive" style="max-height:100px; max-width:100px"
                                                        alt="">
                                                </td>
                                                <td><?php echo e($project->title); ?></td>
                                                <td style="text-align: center;">
                                                    <a href="<?php echo e(route('admin.project.show', $project->id)); ?>"
                                                        class="btn btn-flat-success border">
                                                        Manage
                                                    </a>
                                                    <a class="btn btn-flat-danger border"
                                                        onclick="return confirm('Are you sure?');"
                                                        href="<?php echo e(route('admin.project.destroy', $project->id)); ?>">
                                                        Delete
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="10" class="text-center">No records found!</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <?php echo e($projects->links()); ?>

                    </div>
                </div>



            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.includes.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\al-yasmeen\resources\views/admin/project/index.blade.php ENDPATH**/ ?>