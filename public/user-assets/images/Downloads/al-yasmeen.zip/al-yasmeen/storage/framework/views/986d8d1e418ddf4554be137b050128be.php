<footer class="col-12 admin-footer">
    <div class="row pdt-30 mb-2 footer-copyright-area">
        <div class="col-xl-12">
            <div class="text-center">
                <span>Copyright ©2023 AL Yasmeen All Rights Reserved Developed by
                    <span>
                        <a style="color: #ec2024;" href="https://publicize360.com/"
                            target="_blank">Publicize 360</a>
                        CMS by <a style="color: #04733b;" href="https://acsinsights.com/"
                            target="_blank">ACS Insights</a>
                    </span>
                </span>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\wamp64\www\al-yasmeen\resources\views/admin/includes/footer.blade.php ENDPATH**/ ?>